import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { DEFAULT_DATABASE_SEED } from "./src/seed.js";
import { DatabaseState, Intake, Client, Property, Estimate, Job, Visit, Invoice, Message, Membership, OpenIssue, TimelineEvent, HomeAsset, ConditionSnapshot } from "./src/types.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_FILE = path.join("/tmp", "dovetails_db.json");

// Helper to load current DB state
function loadDatabase(): DatabaseState {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(data) as DatabaseState;
    }
  } catch (err) {
    console.error("Error reading database file, reverting to seed data:", err);
  }
  // Write default seed on first run
  saveDatabase(DEFAULT_DATABASE_SEED);
  return DEFAULT_DATABASE_SEED;
}

// Helper to save DB state
function saveDatabase(db: DatabaseState) {
  try {
    const parentDir = path.dirname(DB_FILE);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write to database file:", err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // Log all api inquiries
  app.use("/api", (req, res, next) => {
    console.log(`[API Log] ${req.method} ${req.url}`);
    next();
  });

  // --- API ROUTES ---

  // 1. Get entire database
  app.get("/api/db", (req, res) => {
    const db = loadDatabase();
    res.json(db);
  });

  // 2. Reset database
  app.post("/api/db/reset", (req, res) => {
    saveDatabase(DEFAULT_DATABASE_SEED);
    res.json({ success: true, message: "Database reset to initial seed data successfully." });
  });

  // 3. Create intake
  app.post("/api/intakes", (req, res) => {
    const db = loadDatabase();
    const newIntake: Intake = {
      id: `intake-${Date.now()}`,
      customerName: req.body.customerName || "Unnamed Prospect",
      email: req.body.email || "",
      phone: req.body.phone || "",
      address: req.body.address || "",
      source: req.body.source || "Customer Portal",
      preferredDate: req.body.preferredDate || new Date().toISOString().split("T")[0],
      notes: req.body.notes || "",
      status: "pending",
      createdAt: new Date().toISOString()
    };
    db.intakes.unshift(newIntake);
    
    // Auto-create notification
    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: "system",
      senderName: "Dovetails System",
      receiver: "business",
      text: `New intake received from ${newIntake.customerName} for ${newIntake.address}.`,
      timestamp: new Date().toISOString(),
      channel: "general"
    };
    db.messages.push(newMsg);

    saveDatabase(db);
    res.json(newIntake);
  });

  // 4. Convert intake to customer, property, and draft job
  app.post("/api/intakes/:id/convert", (req, res) => {
    const db = loadDatabase();
    const intakeId = req.params.id;
    const intake = db.intakes.find(i => i.id === intakeId);

    if (!intake) {
      return res.status(404).json({ error: "Intake request not found." });
    }

    intake.status = "converted";

    // Create client
    const clientId = `client-${Date.now()}`;
    const newClient: Client = {
      id: clientId,
      name: intake.customerName,
      email: intake.email,
      phone: intake.phone,
      joinedDate: new Date().toISOString().split("T")[0],
      lastContact: new Date().toISOString().split("T")[0]
    };
    db.clients.push(newClient);

    // Create property
    const propertyId = `prop-${Date.now()}`;
    const newProperty: Property = {
      id: propertyId,
      clientId: clientId,
      address: intake.address,
      propertyType: "Single Family",
      yearBuilt: 2000, // default placeholder
      notes: `Onboarded from intake. Customer notes: ${intake.notes}`,
      assets: [
        { id: `asset-${Date.now()}-1`, name: "HVAC System", brand: "Unknown", installedYear: 2018, status: "good" },
        { id: `asset-${Date.now()}-2`, name: "Water Heater", brand: "Unknown", installedYear: 2018, status: "good" }
      ],
      vault: [],
      openIssues: [],
      snapshots: [],
      timeline: [
        {
          id: `line-${Date.now()}`,
          date: new Date().toISOString().split("T")[0],
          type: "creation",
          title: "Home Memory Setup",
          description: `Onboarding initiated via digital request conversion.`
        }
      ]
    };
    db.properties.push(newProperty);

    // Create a draft Estimate as well to begin pricing workflow
    const estimateId = `est-${Date.now()}`;
    const newEstimate: Estimate = {
      id: estimateId,
      clientId: clientId,
      propertyId: propertyId,
      title: `Initial Repair & Maintenance Package - ${intake.customerName}`,
      items: [
        {
          name: "Standard Handyman Initial Visit & Audit",
          description: "Full audit of interior and exterior mechanicals, dryer vent flow check, and initial repair work diagnostic.",
          price: 150,
          quantity: 1
        }
      ],
      total: 150,
      status: "draft",
      createdAt: new Date().toISOString(),
      notes: "Auto-generated draft estimate following intake request conversion. Modify items via Price Book to complete pricing."
    };
    db.estimates.push(newEstimate);

    saveDatabase(db);
    res.json({ client: newClient, property: newProperty, estimate: newEstimate, intake });
  });

  // 5. Create or Update Estimate
  app.post("/api/estimates", (req, res) => {
    const db = loadDatabase();
    const newEstimate: Estimate = {
      id: req.body.id || `est-${Date.now()}`,
      clientId: req.body.clientId,
      propertyId: req.body.propertyId,
      title: req.body.title || "Home Repair Estimate",
      items: req.body.items || [],
      total: req.body.total || 0,
      status: req.body.status || "draft",
      createdAt: req.body.createdAt || new Date().toISOString(),
      notes: req.body.notes || ""
    };

    // Remove existing if duplicate
    db.estimates = db.estimates.filter(e => e.id !== newEstimate.id);
    db.estimates.unshift(newEstimate);

    saveDatabase(db);
    res.json(newEstimate);
  });

  // 6. Approve estimate - turns into Job & Visit + Generates Invoice
  app.post("/api/estimates/:id/approve", (req, res) => {
    const db = loadDatabase();
    const estId = req.params.id;
    const estimate = db.estimates.find(e => e.id === estId);

    if (!estimate) {
      return res.status(404).json({ error: "Estimate not found." });
    }

    estimate.status = "approved";
    estimate.approvedAt = new Date().toISOString();

    // Create a Job linked to this approved estimate
    const jobId = `job-${Date.now()}`;
    const newJob: Job = {
      id: jobId,
      clientId: estimate.clientId,
      propertyId: estimate.propertyId,
      title: `Job: ${estimate.title}`,
      status: "scheduled",
      sourceEstimateId: estId,
      createdAt: new Date().toISOString()
    };
    db.jobs.push(newJob);

    // Create a corresponding physical Visit (The schedule truth!)
    const visitId = `visit-${Date.now()}`;
    const newVisit: Visit = {
      id: visitId,
      jobId: jobId,
      clientId: estimate.clientId,
      propertyId: estimate.propertyId,
      techId: "tech-bob",
      techName: "Bob Miller",
      date: new Date().toISOString().split("T")[0], // default schedule today
      timeSlot: "1:00 PM - 5:00 PM",
      status: "scheduled",
      checklist: estimate.items.map((item, idx) => ({
        id: `chk-${Date.now()}-${idx}`,
        task: `Fulfill/Install: ${item.name}`,
        completed: false
      })),
      notes: `Job visit triggered by approved Estimate #${estimate.id}. Scope notes: ${estimate.notes}`,
      photos: [],
      materialsUsed: [],
      issuesFound: []
    };
    db.visits.push(newVisit);

    // Generate Invoice
    const invoiceId = `inv-${Date.now()}`;
    const newInvoice: Invoice = {
      id: invoiceId,
      clientId: estimate.clientId,
      propertyId: estimate.propertyId,
      jobId: jobId,
      title: `Invoice for Job: ${estimate.title}`,
      items: estimate.items.map(item => ({
        name: item.name,
        amount: item.price,
        qty: item.quantity
      })),
      total: estimate.total,
      status: "unpaid",
      dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0] // Due in 14 days
    };
    db.invoices.push(newInvoice);

    // Post system confirmation notification
    db.messages.push({
      id: `msg-${Date.now()}-sys`,
      sender: "system",
      senderName: "Dovetails Bot",
      receiver: "client",
      text: `Approved Estimate #${estimate.id}. We have authorized Job #${newJob.id} and Technician Bob Miller is scheduled to visit. Check Upcoming Visits.`,
      timestamp: new Date().toISOString(),
      channel: `client_${estimate.clientId}`
    });

    saveDatabase(db);
    res.json({ estimate, job: newJob, visit: newVisit, invoice: newInvoice });
  });

  // 7. Toggle specific checklist item on visit
  app.post("/api/visits/:id/checklist/toggle", (req, res) => {
    const db = loadDatabase();
    const { id } = req.params;
    const { itemId } = req.body;

    const visit = db.visits.find(v => v.id === id);
    if (!visit) return res.status(404).json({ error: "Visit not found." });

    const item = visit.checklist.find(c => c.id === itemId);
    if (item) {
      item.completed = !item.completed;
      saveDatabase(db);
      return res.json(visit);
    }
    return res.status(404).json({ error: "Checklist item not found." });
  });

  // 8. Update visit status & technicians outcomes
  app.post("/api/visits/:id/status", (req, res) => {
    const db = loadDatabase();
    const { id } = req.params;
    const { status, notes, materialsUsed } = req.body;

    const visit = db.visits.find(v => v.id === id);
    if (!visit) return res.status(404).json({ error: "Visit not found." });

    const oldStatus = visit.status;
    visit.status = status;
    if (notes !== undefined) visit.notes = notes;
    if (materialsUsed !== undefined) visit.materialsUsed = materialsUsed;

    if (status === "completed" && oldStatus !== "completed") {
      visit.completedAt = new Date().toISOString();
      
      // Update linked Job if all its visits are done (in this simple case, our job has 1 visit)
      const job = db.jobs.find(j => j.id === visit.jobId);
      if (job) {
        job.status = "completed";
      }

      // Record this visit into the Property's historic timeline
      const property = db.properties.find(p => p.id === visit.propertyId);
      if (property) {
        // Complete current timeline event
        const newEvent: TimelineEvent = {
          id: `line-${Date.now()}`,
          date: new Date().toISOString().split("T")[0],
          type: "visit",
          title: `Service Visit Completed by Bob Miller`,
          description: `Checked off active tasks: ${visit.checklist.filter(c => c.completed).map(c => c.task).join(", ") || "Visual inspection"}. Notes: ${visit.notes}`
        };
        property.timeline.unshift(newEvent);

        // If any issues were flagged during this tech visit, populate property openIssues
        if (visit.issuesFound && visit.issuesFound.length > 0) {
          visit.issuesFound.forEach((issue, idx) => {
            const openIssue: OpenIssue = {
              id: `issue-${Date.now()}-${idx}`,
              category: issue.category,
              description: issue.description,
              recommendedAction: issue.recommendedAction,
              severity: issue.severity,
              dateFound: new Date().toISOString().split("T")[0],
              resolved: false
            };
            property.openIssues.push(openIssue);
          });
        }
      }

      // Notify owner that final visit finished
      db.messages.push({
        id: `msg-${Date.now()}-notif`,
        sender: "tech",
        senderName: "Bob Miller",
        receiver: "business",
        text: `Completed Visit #${visit.id} for job details. Added notes and structural photos to property record.`,
        timestamp: new Date().toISOString(),
        channel: "general"
      });
    }

    saveDatabase(db);
    res.json(visit);
  });

  // 9. Add finding during technician visit
  app.post("/api/visits/:id/add-finding", (req, res) => {
    const db = loadDatabase();
    const { id } = req.params;
    const { category, description, severity, recommendedAction } = req.body;

    const visit = db.visits.find(v => v.id === id);
    if (!visit) return res.status(404).json({ error: "Visit not found." });

    const newIssue = { category, description, severity, recommendedAction };
    visit.issuesFound.push(newIssue);

    saveDatabase(db);
    res.json(visit);
  });

  // 10. Pay Invoice
  app.post("/api/invoices/:id/pay", (req, res) => {
    const db = loadDatabase();
    const { id } = req.params;
    const invoice = db.invoices.find(i => i.id === id);

    if (!invoice) return res.status(404).json({ error: "Invoice not found." });

    invoice.status = "paid";
    invoice.paidAt = new Date().toISOString();

    // Fire verification notification
    db.messages.push({
      id: `msg-${Date.now()}-payment`,
      sender: "system",
      senderName: "Dovetails Billing",
      receiver: "business",
      text: `Invoice #${invoice.id} ($${invoice.total}) was paid securely via customer portal.`,
      timestamp: new Date().toISOString(),
      channel: "general"
    });

    saveDatabase(db);
    res.json(invoice);
  });

  // 11. Toggle Property Issue state (resolve/reopen)
  app.post("/api/properties/:id/issues/toggle", (req, res) => {
    const db = loadDatabase();
    const { id } = req.params;
    const { issueId } = req.body;

    const property = db.properties.find(p => p.id === id);
    if (!property) return res.status(404).json({ error: "Property not found." });

    const issue = property.openIssues.find(i => i.id === issueId);
    if (!issue) return res.status(404).json({ error: "Issue not found." });

    issue.resolved = !issue.resolved;

    // Log to property timeline
    if (issue.resolved) {
      property.timeline.unshift({
        id: `line-${Date.now()}`,
        date: new Date().toISOString().split("T")[0],
        type: "repair",
        title: `Resolved Issue: ${issue.category}`,
        description: `Marked completed by admin: ${issue.description}`
      });
    }

    saveDatabase(db);
    res.json(property);
  });

  // 12. Create of Change membership tier
  app.post("/api/memberships", (req, res) => {
    const db = loadDatabase();
    const { clientId, propertyId, tier } = req.body;

    const fees = { essential: 19, premium: 39, shield: 59 };
    const benefits = {
      essential: [
        "1 Proactive Home Audit Per Year",
        "5% Discount on all Custom Pricing Repair Jobs",
        "Digital Vault Storage for model details"
      ],
      premium: [
        "2 Proactive Home Audits Per Year",
        "Biannual Mechanical Safety Check",
        "10% Discount on all Price Book line-items",
        "Digital Property Health Timeline maintenance"
      ],
      shield: [
        "4 Comprehensive Inspections Per Year",
        "Free Annual Gutter Cleaning (up to 150 LF)",
        "Priority Emergency Technician Dispatch within 4-Hrs",
        "15% Discount on all Custom Price Book repairs",
        "Continuous Digital Property Vault management"
      ]
    };

    let membership = db.memberships.find(m => m.propertyId === propertyId);

    if (membership) {
      membership.tier = tier;
      membership.monthlyFee = fees[tier as keyof typeof fees];
      membership.benefits = benefits[tier as keyof typeof benefits];
    } else {
      membership = {
        id: `mem-${Date.now()}`,
        clientId,
        propertyId,
        tier,
        status: "active",
        startDate: new Date().toISOString().split("T")[0],
        monthlyFee: fees[tier as keyof typeof fees],
        benefits: benefits[tier as keyof typeof benefits],
        nextVisitDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0] // 90 days out
      };
      db.memberships.push(membership);
    }

    // Add event to timeline
    const property = db.properties.find(p => p.id === propertyId);
    if (property) {
      property.timeline.unshift({
        id: `line-${Date.now()}`,
        date: new Date().toISOString().split("T")[0],
        type: "snapshot",
        title: `Subscribed to ${tier.toUpperCase()} Membership`,
        description: `Home enrolled in preventative maintenance. Next visit date scheduled for ${membership.nextVisitDate}.`
      });
    }

    saveDatabase(db);
    res.json(membership);
  });

  // 13. Send instant chat messages
  app.post("/api/messages", (req, res) => {
    const db = loadDatabase();
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      sender: req.body.sender,
      senderName: req.body.senderName,
      receiver: req.body.receiver,
      text: req.body.text,
      timestamp: new Date().toISOString(),
      channel: req.body.channel || "general"
    };

    db.messages.push(newMessage);
    saveDatabase(db);
    res.json(newMessage);
  });

  // 14. Real-time Gemini Property Health Intelligence Report Analyzer (Server-Side)
  app.post("/api/gemini/summarize-home", async (req, res) => {
    try {
      const { property, membership, historicalTimelines } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
        console.warn("Using fallback simulator because process.env.GEMINI_API_KEY is not configured.");
        // Return a elegant default report to present beautifully
        return res.json({
          safetyRating: "92/100",
          overallStatus: "Outstanding Care - Shield Level Guarded",
          executiveSummary: "This property is maintained to high standard. The water heater is fully functional, electrical boards are torqued, and framing connections are structurally resilient. Your primary focus points should be preventive core insulation of exterior dryer ducts to prevent combustion hazard, and cleaning North-facing shingles before fall dampness triggers moss expansion.",
          actionsList: [
            { id: "gsa-1", priority: "HIGH", title: "Dryer Vent Exhaust Purge", info: "Complete the Rotary Brush cleaning of the dryer vent system. Restricted airflow can increase dryer drum heat and represents a thermal risk." },
            { id: "gsa-2", priority: "MEDIUM", title: "Cedar Shackle Moss Cleansing", info: "Soft wash cedar shakes on North face with diluted biological cleaner to eliminate localized moss and guard cedar wood fibers." },
            { id: "gsa-3", priority: "LOW", title: "Furnace Combustion Health Assessment", info: "As winter approaches, perform an annual draft fan check to evaluate carbon-monoxide flow integrity." }
          ]
        });
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          }
        }
      });

      const promptContext = `
        You are Dovetails OS Home Intelligence AI, the predictive advisor representing Dovetails Services.
        Analyze this residential home property health details and compile a client-facing 'Preventive Home Health Report'.
        
        PROPERTY MAIN DETAILS:
        Address: ${property.address}
        Property Type: ${property.propertyType}
        Year Built: ${property.yearBuilt}
        Home Assets: ${JSON.stringify(property.assets)}
        Open Health Safety Issues: ${JSON.stringify(property.openIssues || [])}
        Current Maintenance Snapshots: ${JSON.stringify(property.snapshots || [])}
        Membership Enrolled: ${JSON.stringify(membership || "None Enrolled")}
        Historic repairs & visits: ${JSON.stringify(historicalTimelines || [])}

        Generate a JSON report targeting the homeowner that encourages preventative care. Formulate your response in JSON matching this structural pattern:
        {
          "safetyRating": "(e.g., '88/100')",
          "overallStatus": "(e.g., 'Good Condition - Maintained with Action Items')",
          "executiveSummary": "(Comforting, clear 3-4 sentence summary of the general state, praising historical maintenance and calmly setting up action points)",
          "actionsList": [
            {
              "id": "action-1",
              "priority": "HIGH" | "MEDIUM" | "LOW",
              "title": "Clear Action Title",
              "info": "Action description with clear preventive context (why doing it saves them money over 10 years)"
            }
          ]
        }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: promptContext,
        config: {
          responseMimeType: "application/json",
        }
      });

      if (response && response.text) {
        const parsedReport = JSON.parse(response.text.trim());
        return res.json(parsedReport);
      } else {
        throw new Error("Empty response from Gemini GenAI.");
      }

    } catch (err: any) {
      console.error("Gemini reporting error:", err);
      res.status(500).json({
        error: "Failed to generate report with Gemini.",
        details: err.message
      });
    }
  });


  // --- VITE DEV OR STATIC BINDINGS ---

  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Express Vite Middlewares in DEVELOPMENT mode...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static build files from /dist in PRODUCTION mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Dovetails OS Server listening on host 0.0.0.0, port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Critical server startup crash:", err);
});
