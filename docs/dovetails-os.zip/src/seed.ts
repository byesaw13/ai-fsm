import { DatabaseState } from "./types";

export const DEFAULT_DATABASE_SEED: DatabaseState = {
  intakes: [
    {
      id: "intake-1",
      customerName: "David Miller",
      email: "david.miller@gmail.com",
      phone: "(603) 555-0143",
      address: "102 High St, Manchester, NH",
      source: "Web Intake Form",
      preferredDate: "2026-05-28",
      notes: "My back gutter is overflowing right over the basement hatchway during heavy rain. Worried about flooding. Need a clearing and checking for downspout clogs.",
      status: "pending",
      createdAt: "2026-05-23T14:32:00Z"
    },
    {
      id: "intake-2",
      customerName: "Jessica Taylor",
      email: "jtaylor@outlook.com",
      phone: "(603) 555-0211",
      address: "85 Pine Road, Bedford, NH",
      source: "Phone Call",
      preferredDate: "2026-05-30",
      notes: "Outdoor spigot is leaking from the handle whenever the hose is connected and water is on. Might need a packing washer replacement or a brand new frost-free hose bib.",
      status: "pending",
      createdAt: "2026-05-23T18:15:00Z"
    }
  ],
  clients: [
    {
      id: "client-1",
      name: "Sarah Jenkins",
      email: "sarahj@gmail.com",
      phone: "(603) 555-8932",
      joinedDate: "2024-03-15",
      lastContact: "2026-05-23"
    },
    {
      id: "client-2",
      name: "Michael Chang",
      email: "mchang@techpartners.io",
      phone: "(603) 555-4721",
      joinedDate: "2025-06-10",
      lastContact: "2026-05-24"
    }
  ],
  properties: [
    {
      id: "prop-1",
      clientId: "client-1",
      address: "412 Oak Lane, Manchester, NH 03104",
      propertyType: "Single Family Residential",
      yearBuilt: 1984,
      notes: "Original 1980s construction with multiple late-90s renovations. Crawlspace access is via rear deck utility panel. Main water shutoff is in the front closet closet box.",
      assets: [
        {
          id: "asset-1",
          name: "Main Carrier Furnace",
          brand: "Carrier (58PHB070)",
          installedYear: 2014,
          status: "warning"
        },
        {
          id: "asset-2",
          name: "Rheem Water Heater",
          brand: "Rheem Performance Platinum (40-Gal)",
          installedYear: 2019,
          status: "good"
        },
        {
          id: "asset-3",
          name: "GAF Timberline Roof",
          brand: "GAF Asphalt Shingle",
          installedYear: 2008,
          status: "warning"
        }
      ],
      vault: [
        {
          id: "vault-1",
          title: "Carrier Furnace Spec Sheet",
          category: "HVAC / Mechanical",
          description: "Original specification sheet, electrical drawing, and filter replacement guidelines (takes 16x25x1 filters).",
          dateAdded: "2024-03-16"
        },
        {
          id: "vault-2",
          title: "Exterior Paint Codes",
          category: "Paint / Finishes",
          description: "Sherwin Williams Exterior Latex: Siding is 'Slate Tile' (SW 7624), Trims matching 'Alabaster' (SW 7008).",
          dateAdded: "2025-05-12"
        }
      ],
      timeline: [
        {
          id: "time-1",
          date: "2026-01-15",
          type: "repair",
          title: "Bathroom sink slow drain",
          description: "Removed trap, cleared significant biological hair clog, flushed with hot enzymic cleanser, re-seated slip washers."
        },
        {
          id: "time-2",
          date: "2025-11-20",
          type: "visit",
          title: "Winterization & Shield Service Visit",
          description: "Turned off exterior spigot valves inside home, drained spigots, installed insulation covers, inspected attic for pests."
        },
        {
          id: "time-3",
          date: "2024-03-15",
          type: "creation",
          title: "Home Memory Created",
          description: "Initial intake completed. Property blueprint generated, basic assets cataloged as part of Shield Maintenance Plan."
        }
      ],
      openIssues: [
        {
          id: "issue-1",
          category: "Preventative",
          description: "Dryer vent duct showing severe interior lint accumulation. Exhaust backpressure is warm.",
          recommendedAction: "Perform rotary brush dryer vent cleaning from the exterior hood through to the interior laundry terminal.",
          severity: "high",
          dateFound: "2026-05-15",
          resolved: false,
          estimateId: "est-1"
        },
        {
          id: "issue-2",
          category: "Structural",
          description: "Three balusters on front porch cedar railing are unfastened at the base, creating an active child fall hazard.",
          recommendedAction: "Secure loose balusters with countersunk exterior performance deck screws and fill with exterior silicone sealant.",
          severity: "medium",
          dateFound: "2026-05-15",
          resolved: false,
          estimateId: "est-1"
        }
      ],
      snapshots: [
        {
          id: "snap-1",
          date: "2026-05-15",
          sectionName: "Dryer Vent Exhaust Outlet",
          grade: "D",
          details: "Significant damp lint build-up restricted flap clearance. Flap is wedged 70% closed, choking air exhaust.",
          images: []
        },
        {
          id: "snap-2",
          date: "2026-05-15",
          sectionName: "Electrical Sub-breaker Torque Audit",
          grade: "A",
          details: "All sub-panel lugs torqued, no excessive temperatures found via thermal scan. Labels detailed and legible.",
          images: []
        }
      ]
    },
    {
      id: "prop-2",
      clientId: "client-2",
      address: "78 Birch Circle, Bedford, NH 03110",
      propertyType: "Single Family Residential",
      yearBuilt: 2005,
      notes: "Sovereign-style custom build. AC unit is situated in the north setback behind the arborvitae row. Crawlspace is encapsulation-ready.",
      assets: [
        {
          id: "asset-4",
          name: "Trane High-Efficiency Heat Pump",
          brand: "Trane XL18i (4-Ton)",
          installedYear: 2021,
          status: "good"
        },
        {
          id: "asset-5",
          name: "Western Red Cedar Deck",
          brand: "Custom Timber Construction",
          installedYear: 2005,
          status: "good"
        }
      ],
      vault: [
        {
          id: "vault-3",
          title: "Trane Heat Pump Heat Load Report",
          category: "HVAC / Mechanical",
          description: "Original calculations validating the 4-ton cooling sizing against localized square footage.",
          dateAdded: "2025-06-11"
        }
      ],
      timeline: [
        {
          id: "time-4",
          date: "2025-10-12",
          type: "repair",
          title: "Deck Shoring & Guardrail Stabilization",
          description: "Installed heavy-duty Simpson Strong-Tie framing tension ties to deck house ledger connection. Solidified guard posts."
        },
        {
          id: "time-5",
          date: "2025-06-10",
          type: "creation",
          title: "Home Memory Setup",
          description: "Onboarding Michael Chang. Setup premium preventative schedule representing biannual structural inspection."
        }
      ],
      openIssues: [
        {
          id: "issue-3",
          category: "Electrical",
          description: "Master bathroom GFCI outlet is tripping immediately when a hair appliance over 1000W is plugged in. Internal sensor is worn.",
          recommendedAction: "Remove existing outlet, check electrical box box depth, install premium Leviton Smart-Lock 20A weather-resistant GFCI.",
          severity: "high",
          dateFound: "2026-05-23",
          resolved: false,
          estimateId: "est-2"
        }
      ],
      snapshots: [
        {
          id: "snap-3",
          date: "2025-10-12",
          sectionName: "Porch To Rim-Joist Ledger Connection",
          grade: "B",
          details: "Structural flashing is sound. Structural bolts checked and torqued. Highly resilient ledger structure.",
          images: []
        }
      ]
    }
  ],
  memberships: [
    {
      id: "mem-1",
      clientId: "client-1",
      propertyId: "prop-1",
      tier: "shield",
      status: "active",
      startDate: "2024-03-15",
      monthlyFee: 59,
      benefits: [
        "4 Comprehensive Inspections Per Year",
        "Free Annual Gutter Cleaning (up to 150 LF)",
        "Priority Emergency Technician Dispatch within 4 Hrs",
        "15% Discount on all Custom Price Book repairs",
        "Continuous Digital Property Vault management"
      ],
      nextVisitDate: "2026-06-12"
    },
    {
      id: "mem-2",
      clientId: "client-2",
      propertyId: "prop-2",
      tier: "premium",
      status: "active",
      startDate: "2025-06-10",
      monthlyFee: 39,
      benefits: [
        "2 Structured Preventive Visits Per Year",
        "Biannual Mechanical & Combustion Safety Audit",
        "10% Discount on all Price Book line-items",
        "Digital Property Health Timeline maintenance"
      ],
      nextVisitDate: "2026-07-05"
    }
  ],
  priceBook: [
    {
      id: "price-pb1",
      category: "Maintenance",
      name: "Rotary Brush Dryer Vent Cleaning",
      laborBlocks: [
        { name: "Technician setup & visual inspection", hours: 0.5, rate: 85 },
        { name: "Exterior rotary scrubbing run", hours: 1, rate: 100 }
      ],
      materials: [
        { name: "Replacement chrome duct clamps", cost: 12, margin: 0.15 },
        { name: "Replacement premium metal foil ducting (4')", cost: 18, margin: 0.15 }
      ],
      riskFactors: [
        "Restricted access through cabinet partitions",
        "Clogged or crushed rigid line in wall cavity"
      ],
      minimumPrice: 165,
      marginCheck: "64.2% Gross Margin",
      customerDescription: "Comprehensive internal extraction. Includes visual camera check of rigid duct interior, high-pressure booster reverse flush, exhaust exit cowl cleaning and mechanical damper tests."
    },
    {
      id: "price-pb2",
      category: "Electrical",
      name: "GFCI Outlet Upgrade & Board Torque",
      laborBlocks: [
        { name: "Circuit isolation & breaker test", hours: 0.25, rate: 90 },
        { name: "Re-wiring & outlet swap", hours: 0.75, rate: 110 }
      ],
      materials: [
        { name: "Leviton Smart-Lock Pro 20A GFCI", cost: 24, margin: 0.20 },
        { name: "Insulation fire wrap gasket", cost: 3, margin: 0 }
      ],
      riskFactors: [
        "Shallow/crowded 1970s backboxes",
        "Aluminum branch wiring requiring dual-metal alumiconn splices"
      ],
      minimumPrice: 145,
      marginCheck: "71.4% Gross Margin",
      customerDescription: "Remove faulty, degraded outlet. Test ground fault trip resistance milliamps, trim/re-strip conductors, install heavy-duty weather-resistant GFCI receptacle, and apply safety fire wall sealant gaskets."
    },
    {
      id: "price-pb3",
      category: "Plumbing",
      name: "Water Heater Performance Audit & Flush",
      laborBlocks: [
        { name: "Mechanical safety diagnostic", hours: 0.5, rate: 90 },
        { name: "Full core sediment flush & safety relief valve testing", hours: 1, rate: 100 }
      ],
      materials: [
        { name: "Replacement heavy-duty brass drain washer", cost: 4, margin: 0.15 },
        { name: "Replacement T&P release valve", cost: 22, margin: 0.20 }
      ],
      riskFactors: [
        "Rusty, frozen plastic/nylon drain cock",
        "Excessive scale build-up blocking complete flush drainage"
      ],
      minimumPrice: 185,
      marginCheck: "66.5% Gross Margin",
      customerDescription: "Isolate mechanical systems, connect dynamic discharge hose, perform reverse-current bottom sediment flush, clean mechanical gas or electrical burn structures, test temperature-relief pressure valves."
    },
    {
      id: "price-pb4",
      category: "Carpentry",
      name: "Railing / Baluster Structural Securement",
      laborBlocks: [
        { name: "Stabilization assessment & alignment check", hours: 0.5, rate: 80 },
        { name: "Dual-screw countersunk carpentry anchoring", hours: 1, rate: 95 }
      ],
      materials: [
        { name: "#10 3.5\" GRK Structural Deck Screws (50 ct)", cost: 15, margin: 0.15 },
        { name: "Premium exterior wood adhesive/epoxy", cost: 18, margin: 0.15 }
      ],
      riskFactors: [
        "Rotten rim joist or railing sub-plate dry-rot",
        "Cracked cedar wood requiring custom countersunk pilot bores"
      ],
      minimumPrice: 150,
      marginCheck: "62.0% Gross Margin",
      customerDescription: "Align detached balusters into structural balance, coat contact nodes with industrial polyurethane adhesive, mechanically anchor with specialized countersunk fasteners, plug holes, and apply moisture seal."
    }
  ],
  estimates: [
    {
      id: "est-1",
      clientId: "client-1",
      propertyId: "prop-1",
      title: "Preventative Maintenance & Porch Deck Securement",
      items: [
        {
          name: "Rotary Brush Dryer Vent Cleaning",
          description: "Rotary scrubbing of rigid ducting to exterior. Solves high backing temperature and safety fire risks.",
          price: 165,
          quantity: 1
        },
        {
          name: "Railing / Baluster Structural Securement",
          description: "Stabilize detached and loose front porch handrail balusters using structural GRK wood screws.",
          price: 120,
          quantity: 1
        }
      ],
      total: 285,
      status: "sent",
      createdAt: "2026-05-16T10:00:00Z",
      notes: "Prepared following our Shield onboarding survey. Highly recommend executing prior to summer to prevent dryer thermal component breakdown and ensure deck safety."
    },
    {
      id: "est-2",
      clientId: "client-2",
      propertyId: "prop-2",
      title: "Master Bath GFCI Electrical Safety Swap",
      items: [
        {
          name: "GFCI Outlet Upgrade & Board Torque",
          description: "Replace tripping master bathroom outlet with modern self-testing commercial GFCI unit.",
          price: 145,
          quantity: 1
        }
      ],
      total: 145,
      status: "approved",
      createdAt: "2026-05-23T19:00:00Z",
      approvedAt: "2026-05-24T01:15:00Z",
      notes: "Approved by Michael Chang via client portal. Auto-scheduled for today, Sunday May 24th, 2026."
    }
  ],
  jobs: [
    {
      id: "job-1",
      clientId: "client-1",
      propertyId: "prop-1",
      title: "Shield Preventive Pre-Summer Maintenance Check",
      status: "scheduled",
      createdAt: "2026-05-20T08:00:00Z"
    },
    {
      id: "job-2",
      clientId: "client-2",
      propertyId: "prop-2",
      title: "Master Bathroom GFCI Replacement (from approved Estimate #est-2)",
      status: "inprogress",
      createdAt: "2026-05-24T01:16:00Z"
    }
  ],
  visits: [
    {
      id: "visit-1",
      jobId: "job-1",
      clientId: "client-1",
      propertyId: "prop-1",
      techId: "tech-bob",
      techName: "Bob Miller",
      date: "2026-05-24", // TODAY!
      timeSlot: "1:00 PM - 5:00 PM",
      status: "scheduled",
      checklist: [
        { id: "c-1", task: "Cycle Carrier HVAC system check supply/return differential temps", completed: false },
        { id: "c-2", task: "Perform visual water heater anode corrosion assessment", completed: false },
        { id: "c-3", task: "Scrape and clear gutter corners of pine mulch drop", completed: false },
        { id: "c-4", task: "Test smoke and CO alarm dates and swap batteries if outdated", completed: false }
      ],
      notes: "Regular Shield subscription visit. Target is to inspect mechanicals and clean out the minor debris.",
      photos: [],
      materialsUsed: [],
      issuesFound: []
    },
    {
      id: "visit-2",
      jobId: "job-2",
      clientId: "client-2",
      propertyId: "prop-2",
      techId: "tech-bob",
      techName: "Bob Miller",
      date: "2026-05-24", // TODAY!
      timeSlot: "8:00 AM - 12:00 PM",
      status: "arrived",
      checklist: [
        { id: "c-5", task: "Verify master bed breaker circuit is turned off at split panel", completed: true },
        { id: "c-6", task: "Inspect wire insulation inside box for heat cracking", completed: true },
        { id: "c-7", task: "Splice new Leviton wr-GFCI with ground strap connection", completed: false },
        { id: "c-8", task: "Flip breaker and verify 5.5mA ground trip speed test with plug tester", completed: false }
      ],
      notes: "Arrived at 9:15 AM. Michael opened the entrance and indicated the master bedroom bathroom. Currently locking out breaker to perform safe wiring swap.",
      photos: [],
      materialsUsed: [
        { name: "Leviton Smart-Lock Pro 20A GFCI", qty: 1 }
      ],
      issuesFound: []
    }
  ],
  invoices: [
    {
      id: "inv-1",
      clientId: "client-1",
      propertyId: "prop-1",
      jobId: "job-previous",
      title: "Water Heater Diagnostic Flush & Trap Re-seal",
      items: [
        { name: "Water Heater Performance Audit & Flush", amount: 185, qty: 1 }
      ],
      total: 185,
      status: "unpaid",
      dueDate: "2026-06-10"
    },
    {
      id: "inv-2",
      clientId: "client-2",
      propertyId: "prop-2",
      jobId: "job-deck",
      title: "Cedar Porch Structural Framing & Joist Securement",
      items: [
        { name: "Structural ledger framing ties (Materials & Labor)", amount: 450, qty: 1 }
      ],
      total: 450,
      status: "paid",
      dueDate: "2026-05-20",
      paidAt: "2026-05-19T14:40:00Z"
    }
  ],
  messages: [
    {
      id: "msg-1",
      sender: "system",
      senderName: "Dovetails Bot",
      receiver: "client",
      text: "Hello Sarah, Bob will be arriving for your Shield Pre-Summer maintenance check today between 1:00 PM and 5:00 PM. Please make sure crawlspace access is unobstructed.",
      timestamp: "2026-05-24T07:15:00Z",
      channel: "visit-1"
    },
    {
      id: "msg-2",
      sender: "tech",
      senderName: "Bob Miller",
      receiver: "business",
      text: "GFCI outlet replaced. Just testing the trip speed now. The original box had zero ground wire connected! I ran a 12AWG copper pigtail to the metal box core. Safe now.",
      timestamp: "2026-05-24T09:44:00Z",
      channel: "visit-2"
    },
    {
      id: "msg-3",
      sender: "client",
      senderName: "Michael Chang",
      receiver: "business",
      text: "Thanks for checking that ground! I was always worried about why that outlet tripped. Bob is extremely detailed.",
      timestamp: "2026-05-24T09:55:00Z",
      channel: "visit-2"
    }
  ]
};
