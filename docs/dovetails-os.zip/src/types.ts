export enum UserRole {
  ADMIN = "admin",
  TECHNICIAN = "tech",
  CLIENT = "client"
}

export interface Intake {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  source: string; // e.g., "Web Form", "Google", "Phone"
  preferredDate: string;
  notes: string;
  status: "pending" | "converted" | "archived";
  createdAt: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  joinedDate: string;
  lastContact: string;
}

export interface HomeAsset {
  id: string;
  name: string; // e.g., "HVAC System", "Water Heater", "Main Roof"
  brand: string;
  installedYear: number;
  status: "good" | "warning" | "replace";
}

export interface PropertyVaultItem {
  id: string;
  title: string;
  category: string; // e.g., "Manuals", "Paint Codes", "Structural"
  description: string;
  dateAdded: string;
}

export interface TimelineEvent {
  id: string;
  date: string;
  type: "visit" | "repair" | "condition" | "snapshot" | "creation";
  title: string;
  description: string;
  images?: string[];
}

export interface OpenIssue {
  id: string;
  category: string;
  description: string;
  recommendedAction: string;
  severity: "low" | "medium" | "high";
  dateFound: string;
  resolved: boolean;
  estimateId?: string; // Links to an estimate if we generated one
}

export interface ConditionSnapshot {
  id: string;
  date: string;
  sectionName: string; // e.g., "Electrical Panel", "Crawlspace Dryer Vent", "Siding Exterior"
  grade: "A" | "B" | "C" | "D" | "F";
  details: string;
  images: string[];
}

export interface Property {
  id: string;
  clientId: string;
  address: string;
  propertyType: string; // e.g., "Single Family", "Townhouse"
  yearBuilt: number;
  notes: string;
  assets: HomeAsset[];
  vault: PropertyVaultItem[];
  timeline: TimelineEvent[];
  openIssues: OpenIssue[];
  snapshots: ConditionSnapshot[];
}

export interface Membership {
  id: string;
  clientId: string;
  propertyId: string;
  tier: "essential" | "premium" | "shield";
  status: "active" | "paused" | "expired";
  startDate: string;
  monthlyFee: number;
  benefits: string[];
  nextVisitDate: string;
}

export interface LaborBlock {
  name: string;
  hours: number;
  rate: number;
}

export interface MaterialCost {
  name: string;
  cost: number;
  margin: number; // e.g., 0.15 for 15% markup
}

export interface PriceBookItem {
  id: string;
  category: "Plumbing" | "Electrical" | "HVAC" | "Carpentry" | "Handyman" | "Maintenance";
  name: string;
  laborBlocks: LaborBlock[];
  materials: MaterialCost[];
  riskFactors: string[];
  minimumPrice: number;
  marginCheck: string; // e.g., "65% Margin"
  customerDescription: string;
}

export interface EstimateItem {
  name: string;
  description: string;
  price: number;
  quantity: number;
}

export interface Estimate {
  id: string;
  clientId: string;
  propertyId: string;
  title: string;
  items: EstimateItem[];
  total: number;
  status: "draft" | "sent" | "approved" | "declined";
  createdAt: string;
  approvedAt?: string;
  notes: string;
}

export interface ChecklistItem {
  id: string;
  task: string;
  completed: boolean;
}

export interface MaterialUsed {
  name: string;
  qty: number;
  cost?: number;
}

export interface IssueFound {
  category: string;
  description: string;
  severity: "low" | "medium" | "high";
  recommendedAction: string;
}

export interface Visit {
  id: string;
  jobId: string;
  clientId: string;
  propertyId: string;
  techId: string;
  techName: string;
  date: string;
  timeSlot: string; // e.g., "8:00 AM - 12:00 PM"
  status: "scheduled" | "on_way" | "arrived" | "completed";
  checklist: ChecklistItem[];
  notes: string;
  photos: string[];
  materialsUsed: MaterialUsed[];
  issuesFound: IssueFound[];
  completedAt?: string;
}

export interface Job {
  id: string;
  clientId: string;
  propertyId: string;
  title: string;
  status: "unscheduled" | "scheduled" | "inprogress" | "completed";
  sourceEstimateId?: string;
  createdAt: string;
}

export interface InvoiceItem {
  name: string;
  amount: number;
  qty: number;
}

export interface Invoice {
  id: string;
  clientId: string;
  propertyId: string;
  jobId: string;
  title: string;
  items: InvoiceItem[];
  total: number;
  status: "draft" | "sent" | "unpaid" | "paid";
  dueDate: string;
  paidAt?: string;
}

export interface Message {
  id: string;
  sender: "system" | "business" | "tech" | "client";
  senderName: string;
  receiver: "business" | "tech" | "client";
  text: string;
  timestamp: string;
  channel: string; // e.g. "general", "visit_v1", "client_c1"
}

export interface DatabaseState {
  intakes: Intake[];
  clients: Client[];
  properties: Property[];
  memberships: Membership[];
  priceBook: PriceBookItem[];
  estimates: Estimate[];
  jobs: Job[];
  visits: Visit[];
  invoices: Invoice[];
  messages: Message[];
}
