import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import AdminMyDay from "./components/AdminMyDay";
import AdminIntake from "./components/AdminIntake";
import AdminProperties from "./components/AdminProperties";
import AdminPriceBook from "./components/AdminPriceBook";
import AdminEstimates from "./components/AdminEstimates";
import AdminMemberships from "./components/AdminMemberships";
import TechnicianFlow from "./components/TechnicianFlow";
import ClientPortal from "./components/ClientPortal";
import NotificationsPanel from "./components/NotificationsPanel";
import { DatabaseState, UserRole, Intake, PriceBookItem, Estimate, HomeAsset, PropertyVaultItem, OpenIssue, Visit, IssueFound, MaterialUsed } from "./types";
import { Loader2, AlertCircle } from "lucide-react";

export default function App() {
  const [activeRole, setActiveRole] = useState<UserRole>(UserRole.ADMIN);
  const [activeTab, setActiveTab] = useState<string>("myday");
  const [db, setDb] = useState<DatabaseState | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorText, setErrorText] = useState<string>("");
  const [successToast, setSuccessToast] = useState<string>("");

  // Auto hide visual success toasts
  useEffect(() => {
    if (successToast) {
      const timer = setTimeout(() => setSuccessToast(""), 3500);
      return () => clearTimeout(timer);
    }
  }, [successToast]);

  // Load backend database on mount
  useEffect(() => {
    fetchDb();
  }, []);

  const fetchDb = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/db");
      if (!res.ok) throw new Error("Could not load backend database state.");
      const data = await res.json();
      setDb(data);
    } catch (err: any) {
      setErrorText(err.message || "Express server is booting or offline.");
    } finally {
      setLoading(false);
    }
  };

  const syncStateWithServer = async (method: string, endpoint: string, body?: any) => {
    try {
      const res = await fetch(endpoint, {
        method,
        headers: { "Content-Type": "application/json" },
        body: body ? JSON.stringify(body) : undefined
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to commit state payload to server backend.");
      }
      const updatedDb = await res.json();
      setDb(updatedDb);
      return updatedDb;
    } catch (err: any) {
      console.error("Endpoint Synchronization incident:", err);
      setErrorText(err.message || "Operation failed to sync with the JSON database.");
      setTimeout(() => setErrorText(""), 4000);
      throw err;
    }
  };

  // HANDLERS FOR ALL CORE WORKFLOWS

  // 1. Intake Actions
  const handleCreateIntake = async (intakeData: Omit<Intake, "id" | "status" | "createdAt">) => {
    await syncStateWithServer("POST", "/api/intakes", intakeData);
    setSuccessToast("Intake ticket successfully recorded into the dispatch pool!");
  };

  const handleConvertIntake = async (id: string) => {
    await syncStateWithServer("POST", `/api/intakes/${id}/convert`);
    setSuccessToast("Converted ticket to Home record and membership potential.");
  };

  // 2. Property Actions
  const handleToggleIssue = async (propId: string, issueId: string) => {
    await syncStateWithServer("POST", `/api/properties/${propId}/issues/${issueId}/toggle`);
    setSuccessToast("Home hazard resolution status synchronized.");
  };

  const handleAddAsset = async (propId: string, asset: Omit<HomeAsset, "id">) => {
    await syncStateWithServer("POST", `/api/properties/${propId}/assets`, asset);
    setSuccessToast("New mechanical system recorded in Property records.");
  };

  const handleAddVaultItem = async (propId: string, item: Omit<PropertyVaultItem, "id">) => {
    await syncStateWithServer("POST", `/api/properties/${propId}/vault`, item);
    setSuccessToast("User manual successfully archived into the Document vault.");
  };

  const handleBuildEstimateFromIssue = (propertyId: string, issue: OpenIssue) => {
    setActiveTab("estimates");
    setSuccessToast(`Preloaded finding "${issue.category}" into estimate scope!`);
  };

  // 3. Price Book Actions
  const handleAddPriceBookItem = async (item: PriceBookItem) => {
    await syncStateWithServer("POST", "/api/pricebook", item);
    setSuccessToast("Price Book repair template successfully committed.");
  };

  // 4. Estimate Actions
  const handleAddEstimate = async (estimate: Estimate) => {
    await syncStateWithServer("POST", "/api/estimates", estimate);
    setSuccessToast("Estimate published! Waiting checkout confirmation.");
  };

  const handleApproveEstimate = async (id: string) => {
    await syncStateWithServer("POST", `/api/estimates/${id}/approve`);
    setSuccessToast("Estimate approved! Generating safety dispatches & accounts.");
  };

  // 5. Billing Invoice Actions
  const handlePayInvoice = async (id: string) => {
    await syncStateWithServer("POST", `/api/invoices/${id}/pay`);
    setSuccessToast("Invoice payment processed. Records clear.");
  };

  // 6. Technician Mobile Flow Actions
  const handleUpdateVisitStatus = async (id: string, status: Visit["status"], notes?: string, materialsUsed?: MaterialUsed[]) => {
    await syncStateWithServer("POST", `/api/visits/${id}/status`, { status, notes, materialsUsed });
    setSuccessToast(`Route status updated to: ${status.toUpperCase()}`);
  };

  const handleToggleChecklist = async (visitId: string, itemId: string) => {
    await syncStateWithServer("POST", `/api/visits/${visitId}/checklist/toggle`, { itemId });
  };

  const handleAddFinding = async (visitId: string, finding: IssueFound) => {
    await syncStateWithServer("POST", `/api/visits/${visitId}/add-finding`, finding);
    setSuccessToast("Hazards logged. Recorded straight to property timelines.");
  };

  // 7. Membership Actions
  const handleSubscribeMembership = async (clientId: string, propertyId: string, tier: "essential" | "premium" | "shield") => {
    await syncStateWithServer("POST", "/api/memberships", { clientId, propertyId, tier });
    setSuccessToast(`Successfully enrolled property into Dovetails ${tier.toUpperCase()} Membership!`);
  };

  // Loader screen if db isn't resolved
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50">
        <div className="text-center space-y-4">
          <Loader2 className="h-10 w-10 text-emerald-600 animate-spin mx-auto animate-pulse" />
          <h4 className="font-semibold text-slate-800 tracking-tight">Accessing Dovetails OS Portal</h4>
          <p className="text-xs text-slate-400">Loading enterprise physical home memory assets...</p>
        </div>
      </div>
    );
  }

  if (!db) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50 p-6">
        <div className="max-w-md bg-white border border-slate-200 shadow-sm rounded-xl p-8 text-center space-y-4">
          <AlertCircle className="h-12 w-12 text-rose-500 mx-auto" />
          <h4 className="font-semibold text-slate-800">Connection Interrupted</h4>
          <p className="text-xs text-slate-500">
            Express server backend could not persist state coordinates. Verify port binds and dependencies.
          </p>
          <button
            onClick={fetchDb}
            className="w-full py-2 px-4 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition"
          >
            Retry Database Access
          </button>
        </div>
      </div>
    );
  }

  // Derived counts for Sidebar badges
  const unpaidCount = db.invoices.filter(i => i.status === "unpaid").length;
  const pendingIntakesCount = db.intakes.filter(i => i.status === "pending").length;
  const pendingEstimatesCount = db.estimates.filter(e => e.status === "sent").length;

  return (
    <div className="flex h-screen min-h-0 bg-slate-50 overflow-hidden font-sans" id="dovetails-app-root">
      
      {/* Visual Feedback: Success Toasts Alert Popups */}
      {successToast && (
        <div className="fixed top-6 right-6 bg-slate-900 border border-slate-800 text-white shadow-xl rounded-xl py-3.5 px-5 z-55 flex items-center gap-2.5 animate-slide-in shrink-0 max-w-sm z-50">
          <div className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
          <p className="text-xs font-semibold leading-normal font-sans">{successToast}</p>
        </div>
      )}

      {/* Persistent left rail Navigation Panel */}
      <Sidebar
        currentRole={activeRole}
        activeTab={activeTab}
        onChangeRole={(role) => {
          setActiveRole(role);
          if (role === UserRole.ADMIN) setActiveTab("myday");
          if (role === UserRole.TECHNICIAN) setActiveTab("tech-today");
          if (role === UserRole.CLIENT) setActiveTab("client-portal");
        }}
        onSelectTab={setActiveTab}
        unpaidCount={unpaidCount}
        pendingIntakes={pendingIntakesCount}
        pendingEstimates={pendingEstimatesCount}
      />

      {/* Main scrolling content frame */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50/40 relative">
        <div className="flex-1 overflow-y-auto p-6 md:p-8 lg:p-10">
          
          <div className="max-w-7xl mx-auto space-y-6">
            
            {/* Visual Global Error indicators for sandbox stability */}
            {errorText && (
              <div className="p-3.5 bg-rose-50 border border-rose-250 text-rose-800 rounded-xl flex items-start gap-2.5 leading-snug animate-fade-in text-xs shrink-0 font-medium">
                <AlertCircle className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
                <span>{errorText}</span>
              </div>
            )}

            {/* PAGE VIEWS DISPATCHER TAB */}

            {/* ROLE: Admin Tabs */}
            {activeRole === UserRole.ADMIN && (
              <>
                {activeTab === "myday" && (
                  <AdminMyDay
                    db={db}
                    onApproveEstimate={handleApproveEstimate}
                    onRecordPayment={handlePayInvoice}
                    onBuildEstimateFromIssue={handleBuildEstimateFromIssue}
                    onSelectTab={setActiveTab}
                  />
                )}
                {activeTab === "intake" && (
                  <AdminIntake
                    db={db}
                    onCreateIntake={handleCreateIntake}
                    onConvertIntake={handleConvertIntake}
                  />
                )}
                {activeTab === "properties" && (
                  <AdminProperties
                    db={db}
                    onToggleIssue={handleToggleIssue}
                    onAddAsset={handleAddAsset}
                    onAddVaultItem={handleAddVaultItem}
                    onBuildEstimateFromIssue={handleBuildEstimateFromIssue}
                  />
                )}
                {activeTab === "pricebook" && (
                  <AdminPriceBook
                    db={db}
                    onAddPriceBookItem={handleAddPriceBookItem}
                  />
                )}
                {activeTab === "estimates" && (
                  <AdminEstimates
                    db={db}
                    onAddEstimate={handleAddEstimate}
                    onApproveEstimate={handleApproveEstimate}
                  />
                )}
                {activeTab === "memberships" && (
                  <AdminMemberships
                    db={db}
                    onSubscribeMembership={handleSubscribeMembership}
                  />
                )}
                {activeTab === "invoices" && (
                  <AdminMyDay
                    db={db}
                    onApproveEstimate={handleApproveEstimate}
                    onRecordPayment={handlePayInvoice}
                    onBuildEstimateFromIssue={handleBuildEstimateFromIssue}
                    onSelectTab={setActiveTab}
                  />
                )}
                {activeTab === "logs" && (
                  <NotificationsPanel db={db} />
                )}
              </>
            )}

            {/* ROLE: Technician Tabs */}
            {activeRole === UserRole.TECHNICIAN && (
              <>
                {activeTab === "tech-today" && (
                  <TechnicianFlow
                    db={db}
                    onUpdateVisitStatus={handleUpdateVisitStatus}
                    onToggleChecklist={handleToggleChecklist}
                    onAddFinding={handleAddFinding}
                  />
                )}
              </>
            )}

            {/* ROLE: Client/Homeowner Tabs */}
            {activeRole === UserRole.CLIENT && (
              <>
                {activeTab === "client-portal" && (
                  <ClientPortal
                    db={db}
                    onApproveEstimate={handleApproveEstimate}
                    onPayInvoice={handlePayInvoice}
                  />
                )}
              </>
            )}

          </div>

        </div>
      </main>

    </div>
  );
}
