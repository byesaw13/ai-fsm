import React, { useState } from "react";
import { 
  HeartHandshake, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  Plus, 
  User, 
  MapPin, 
  CalendarDays 
} from "lucide-react";
import { DatabaseState } from "../types";

interface AdminMembershipsProps {
  db: DatabaseState;
  onSubscribeMembership: (clientId: string, propertyId: string, tier: "essential" | "premium" | "shield") => void;
}

export default function AdminMemberships({
  db,
  onSubscribeMembership
}: AdminMembershipsProps) {
  const [selectedClientId, setSelectedClientId] = useState(db.clients[0]?.id || "");
  const [selectedPropertyId, setSelectedPropertyId] = useState("");
  const [selectedTier, setSelectedTier] = useState<"essential" | "premium" | "shield">("premium");

  // Align property selection automatically
  React.useEffect(() => {
    const clientProperties = db.properties.filter(p => p.clientId === selectedClientId);
    if (clientProperties.length > 0) {
      setSelectedPropertyId(clientProperties[0].id);
    } else {
      setSelectedPropertyId("");
    }
  }, [selectedClientId, db.properties]);

  const handleEnroll = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClientId || !selectedPropertyId) return;
    onSubscribeMembership(selectedClientId, selectedPropertyId, selectedTier);
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case "shield":
        return <ShieldCheck className="h-6 w-6 text-emerald-600 shrink-0" />;
      case "premium":
        return <Sparkles className="h-6 w-6 text-indigo-600 shrink-0" />;
      default:
        return <HeartHandshake className="h-6 w-6 text-blue-600 shrink-0" />;
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="admin-memberships-view">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Preventative Maintenance Memberships</h2>
        <p className="text-sm text-slate-500 mt-1 font-sans">
          Transitioning home services from random emergency calls to scheduled relationship-first care.
        </p>
      </div>

      {/* Package tier layouts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Tier 1: Essential */}
        <div className="bg-white border-2 border-slate-100 rounded-xl p-6 space-y-4 hover:border-blue-400 transition flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              {getTierIcon("essential")}
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-600 bg-blue-50 px-2.5 py-1 rounded font-mono">
                Essential Plan
              </span>
            </div>
            <div>
              <span className="text-2xl font-bold font-mono text-slate-950">$19</span>
              <span className="text-xs text-slate-400 font-sans"> / month</span>
            </div>
            <p className="text-xs text-slate-500 font-sans leading-relaxed">
              Standard yearly diagnostic care package modeled to catch minor plumbing and combustion issues before expensive components decay.
            </p>
            <ul className="text-xs text-slate-600 font-sans space-y-2 pt-2 border-t border-slate-100 shrink-0">
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-blue-500 shrink-0 mt-0.5" />
                <span>1 Comprehensive Home Audit Per Year</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-blue-500 shrink-0 mt-0.5" />
                <span>5% Discount on all custom price list repairs</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-blue-500 shrink-0 mt-0.5" />
                <span>Continuous Digital Vault records</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Tier 2: Premium (Recommended) */}
        <div className="bg-white border-2 border-indigo-500/80 rounded-xl p-6 space-y-4 shadow-sm hover:border-indigo-500/100 transition flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-indigo-500 text-white font-bold uppercase tracking-widest text-[8px] py-1 px-3 rounded-bl">
            Recommended
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              {getTierIcon("premium")}
              <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded font-mono">
                Premium Plan
              </span>
            </div>
            <div>
              <span className="text-2xl font-bold font-mono text-slate-950">$39</span>
              <span className="text-xs text-slate-400 font-sans"> / month</span>
            </div>
            <p className="text-xs text-slate-500 font-sans leading-relaxed">
              Biannual seasonal structural checks crafted for active families to solidify decks, purge drain gutters, and secure crawlspace vents.
            </p>
            <ul className="text-xs text-slate-600 font-sans space-y-2 pt-2 border-t border-slate-100 shrink-0">
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-indigo-500 shrink-0 mt-0.5" />
                <span>2 Proactive Home Audits Per Year</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-indigo-500 shrink-0 mt-0.5" />
                <span>Biannual Mechanical Safety Audits</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-indigo-500 shrink-0 mt-0.5" />
                <span>10% Discount on all Price Book repairs</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-indigo-500 shrink-0 mt-0.5" />
                <span>Digital Property Care Timeline Log</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Tier 3: Shield (Complete Defense) */}
        <div className="bg-white border-2 border-slate-100 rounded-xl p-6 space-y-4 hover:border-emerald-400 transition flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              {getTierIcon("shield")}
              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded font-mono">
                Shield Plan
              </span>
            </div>
            <div>
              <span className="text-2xl font-bold font-mono text-slate-950">$59</span>
              <span className="text-xs text-slate-400 font-sans"> / month</span>
            </div>
            <p className="text-xs text-slate-500 font-sans leading-relaxed">
              Continuous quarterly maintenance defense designed to provide ultimate security. Priority dispatcher dispatch when components snap.
            </p>
            <ul className="text-xs text-slate-600 font-sans space-y-2 pt-2 border-t border-slate-100 shrink-0">
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
                <span>4 Comprehensive Audits Per Year</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
                <span>Free Annual Downspout Gutter Clearing</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
                <span>Priority Emergency Dispatch response (within 4 hrs)</span>
              </li>
              <li className="flex items-start gap-1.5 leading-snug">
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
                <span>15% Discount on all Price Book options</span>
              </li>
            </ul>
          </div>
        </div>

      </div>

      {/* Grid: Onboarding and active members */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-10">
        
        {/* Onboard Subscription (With Labels Above Fields) */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-6 h-fit space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
            <Plus className="h-5 w-5 text-emerald-600" />
            <span className="font-semibold text-slate-900">Enroll Property Membership</span>
          </div>

          <form onSubmit={handleEnroll} className="space-y-4 font-sans text-xs">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Select Client Owner
              </label>
              <select
                id="mem-form-client"
                value={selectedClientId}
                onChange={(e) => setSelectedClientId(e.target.value)}
                className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2.5 focus:outline-emerald-500"
              >
                {db.clients.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.email})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Target Property Record
              </label>
              <select
                id="mem-form-property"
                value={selectedPropertyId}
                onChange={(e) => setSelectedPropertyId(e.target.value)}
                className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2.5 focus:outline-emerald-500"
              >
                {db.properties
                  .filter(p => p.clientId === selectedClientId)
                  .map(p => (
                    <option key={p.id} value={p.id}>{p.address.split(",")[0]}</option>
                  ))
                }
                {db.properties.filter(p => p.clientId === selectedClientId).length === 0 && (
                  <option value="">No Property Records Registered</option>
                )}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Subscription Tier Package
              </label>
              <select
                id="mem-form-tier"
                value={selectedTier}
                onChange={(e) => setSelectedTier(e.target.value as any)}
                className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2.5 focus:outline-emerald-500 font-bold text-slate-900"
              >
                <option value="essential">Essential Core Membership ($19/mo)</option>
                <option value="premium">Premium Seasonal Membership ($39/mo)</option>
                <option value="shield">Shield Continuous Care Membership ($59/mo)</option>
              </select>
            </div>

            <button
              id="mem-form-submit-btn"
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-900 font-bold tracking-tight text-sm text-center transition shadow-xs"
            >
              Confirm Subscription Plan
            </button>
          </form>
        </div>

        {/* Enrolled listings */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <h3 className="font-semibold text-slate-900">Enrolled House Maintenance Memberships</h3>
            <span className="text-xs font-mono font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
              {db.memberships.length} active plans
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {db.memberships.length === 0 ? (
              <div className="p-12 text-center text-slate-400 text-sm">
                No active preventative memberships registered plan on file.
              </div>
            ) : (
              db.memberships.map(mem => {
                const client = db.clients.find(c => c.id === mem.clientId);
                const property = db.properties.find(p => p.id === mem.propertyId);

                return (
                  <div key={mem.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        {mem.tier === "shield" ? (
                          <span className="inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                            {mem.tier} Tier Plan
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                            {mem.tier} Tier Plan
                          </span>
                        )}
                        <span className="text-xs text-slate-400 font-mono">#{mem.id}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 mt-1">
                        {client ? client.name : "Subscribed Client"}
                      </h4>
                      <p className="text-xs text-slate-500 font-sans flex items-start gap-1">
                        <MapPin className="h-3.5 w-3.5 mt-0.5 text-emerald-600 shrink-0" />
                        <span>{property ? property.address : "No Address"}</span>
                      </p>
                    </div>

                    <div className="flex items-start sm:items-end flex-col gap-1.5 shrink-0 text-left sm:text-right">
                      <div className="flex items-center gap-1">
                        <span className="text-sm font-bold text-slate-950 font-mono">${mem.monthlyFee}</span>
                        <span className="text-[10px] text-slate-400">/mo</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-sans flex items-center gap-1">
                        <CalendarDays className="h-3.5 w-3.5" />
                        <span>Next audit: <span className="font-semibold text-slate-800">{mem.nextVisitDate}</span></span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
