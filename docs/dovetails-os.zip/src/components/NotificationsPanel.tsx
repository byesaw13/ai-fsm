import React from "react";
import { DatabaseState, Message } from "../types";
import { History, Bell, Calendar, ClipboardCheck, DollarSign, HeartHandshake } from "lucide-react";

interface NotificationsPanelProps {
  db: DatabaseState;
}

export default function NotificationsPanel({ db }: NotificationsPanelProps) {
  const getEventIcon = (sender: Message["sender"]) => {
    switch (sender) {
      case "system":
        return <Bell className="h-4.5 w-4.5 text-blue-600" />;
      case "business":
        return <ClipboardCheck className="h-4.5 w-4.5 text-indigo-600" />;
      case "tech":
        return <Calendar className="h-4.5 w-4.5 text-emerald-600" />;
      case "client":
        return <DollarSign className="h-4.5 w-4.5 text-emerald-600" />;
      default:
        return <HeartHandshake className="h-4.5 w-4.5 text-purple-600" />;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in font-sans" id="audit-logs-view">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Enterprise Event Audit Trail</h2>
        <p className="text-sm text-slate-500 mt-1">
          A real-time tamper-proof system log documenting client onboardings, technician reports, and billing postings.
        </p>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-1.5 uppercase tracking-wide">
            <History className="h-4.5 w-4.5 text-slate-500" />
            <span>Audit Trail Ledger</span>
          </h3>
          <span className="text-xs font-mono bg-slate-200 text-slate-600 font-bold px-2 py-0.5 rounded">
            {db.messages?.length || 0} entries
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {!db.messages || db.messages.length === 0 ? (
            <div className="p-16 text-center text-slate-400">
              No historic logs found on system database.
            </div>
          ) : (
            db.messages.slice().reverse().map(act => (
              <div key={act.id} className="p-5 flex items-start gap-4 hover:bg-slate-50/50 transition duration-150">
                <div className={`p-2 rounded-lg shrink-0 ${
                  act.sender === "system" 
                    ? "bg-blue-50 text-blue-700" 
                    : act.sender === "business" 
                    ? "bg-indigo-50 text-indigo-700" 
                    : act.sender === "tech" 
                    ? "bg-emerald-50 text-emerald-700" 
                    : act.sender === "client" 
                    ? "bg-emerald-50 text-emerald-700" 
                    : "bg-purple-50 text-purple-700"
                }`}>
                  {getEventIcon(act.sender)}
                </div>

                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                      {act.sender} Log
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(act.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900 leading-snug">
                    {act.senderName} Action
                  </h4>
                  <p className="text-xs text-slate-600 font-sans leading-normal">
                    {act.text}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
