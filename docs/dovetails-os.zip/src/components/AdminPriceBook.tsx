import React, { useState } from "react";
import { 
  BookOpen, 
  Layers, 
  Maximize2, 
  Percent, 
  Activity, 
  HelpCircle, 
  Plus, 
  DollarSign, 
  Cpu, 
  AlertTriangle 
} from "lucide-react";
import { DatabaseState, PriceBookItem, LaborBlock, MaterialCost } from "../types";

interface AdminPriceBookProps {
  db: DatabaseState;
  onAddPriceBookItem: (item: PriceBookItem) => void;
}

export default function AdminPriceBook({
  db,
  onAddPriceBookItem
}: AdminPriceBookProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  
  // Custom Form states for adding items
  const [name, setName] = useState("");
  const [category, setCategory] = useState<PriceBookItem["category"]>("Handyman");
  const [laborName, setLaborName] = useState("Technician standard run");
  const [laborHours, setLaborHours] = useState(1);
  const [laborRate, setLaborRate] = useState(90);
  
  const [matName, setMatName] = useState("Incidental hardware");
  const [matCost, setMatCost] = useState(15);
  const [matMargin, setMatMargin] = useState(0.15);

  const [minimumPrice, setMinimumPrice] = useState(150);
  const [customerDescription, setCustomerDescription] = useState("");
  const [riskFactor, setRiskFactor] = useState("Restricted access bounds");
  
  const categories: string[] = ["All", "Maintenance", "Electrical", "Plumbing", "HVAC", "Carpentry", "Handyman"];

  const filteredItems = selectedCategory === "All" 
    ? db.priceBook 
    : db.priceBook.filter(item => item.category === selectedCategory);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !customerDescription.trim()) return;

    // Build sub objects
    const laborBlocks: LaborBlock[] = [{ name: laborName, hours: laborHours, rate: laborRate }];
    const materials: MaterialCost[] = [{ name: matName, cost: matCost, margin: matMargin }];

    // Simple markup calculated gross margin estimation
    const totalLaborCost = laborHours * laborRate;
    const materialPrice = matCost * (1 + matMargin);
    const estimatedInvoicePrice = Math.max(totalLaborCost + materialPrice, minimumPrice);
    const materialTrueCost = matCost;
    const marginRatio = ((estimatedInvoicePrice - materialTrueCost) / estimatedInvoicePrice) * 100;
    const marginCheck = `${marginRatio.toFixed(1)}% Gross Margin`;

    const newItem: PriceBookItem = {
      id: `price-pb-${Date.now()}`,
      category,
      name,
      laborBlocks,
      materials,
      riskFactors: [riskFactor || "Standard risk"],
      minimumPrice,
      marginCheck,
      customerDescription
    };

    onAddPriceBookItem(newItem);

    // Reset Form
    setName("");
    setCustomerDescription("");
    setLaborHours(1);
    setMatCost(15);
  };

  return (
    <div className="space-y-8 animate-fade-in" id="admin-pricebook-view">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Dovetails Service Price Book</h2>
        <p className="text-sm text-slate-500 mt-1 font-sans">
          The business cornerstone decision engine. Build high-integrity labor blocks and material markup templates to compile fast, accurate, and highly profitable estimates.
        </p>
      </div>

      {/* Category Toggles Slider */}
      <div className="flex gap-2 overflow-x-auto pb-1.5 shrink-0 select-none">
        {categories.map(cat => (
          <button
            id={`pricebook-cat-${cat}`}
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`py-1.5 px-4 rounded-full text-xs font-bold uppercase tracking-wider transition shrink-0 ${
              selectedCategory === cat 
                ? "bg-slate-900 text-white" 
                : "bg-slate-100 hover:bg-slate-200 text-slate-600"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Two-Column split */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        
        {/* Left Column: Price Book Item Display List */}
        <div className="xl:col-span-2 space-y-4">
          {filteredItems.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400">
              <BookOpen className="h-10 w-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-700">No template items found in {selectedCategory}</p>
            </div>
          ) : (
            filteredItems.map(item => {
              // Calculate pricing metrics for admin
              const laborTotal = item.laborBlocks.reduce((acc, lb) => acc + (lb.hours * lb.rate), 0);
              const materialsTotal = item.materials.reduce((acc, mc) => acc + (mc.cost * (1 + mc.margin)), 0);
              const calculatedCost = laborTotal + materialsTotal;
              const suggestedRetailPrice = Math.max(calculatedCost, item.minimumPrice);

              return (
                <div 
                  key={item.id} 
                  className="bg-white border border-slate-200 rounded-xl shadow-xs p-6 space-y-4 hover:border-emerald-500 transition"
                >
                  {/* Title Bar */}
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold uppercase tracking-widest text-slate-400 font-mono">
                          {item.category}
                        </span>
                        <span className="text-xs font-mono font-medium text-slate-400">
                          ID: {item.id}
                        </span>
                      </div>
                      <h4 className="text-md font-bold text-slate-900 mt-1">{item.name}</h4>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs text-slate-400 font-sans block">Minimum Service Price</span>
                      <span className="text-lg font-mono font-bold text-slate-950">${item.minimumPrice}</span>
                    </div>
                  </div>

                  {/* Customer Description Block */}
                  <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
                    <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1 leading-none">
                      Customer-Facing Invoice Description
                    </span>
                    <p className="text-xs text-slate-600 font-sans leading-relaxed">
                      {item.customerDescription}
                    </p>
                  </div>

                  {/* Pricing Matrix Blocks */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-sans">
                    
                    {/* Labor Blocks */}
                    <div className="border border-slate-150 rounded-lg p-3 bg-white space-y-1.5">
                      <span className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider leading-none">
                        Labor blocks
                      </span>
                      {item.laborBlocks.map((lb, idx) => (
                        <div key={idx} className="flex justify-between items-center text-[11px]">
                          <span className="text-slate-600 truncate max-w-[130px]">{lb.name}</span>
                          <span className="font-mono text-slate-950 font-medium whitespace-nowrap">
                            {lb.hours}h @ ${lb.rate}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Material Margin Check */}
                    <div className="border border-slate-150 rounded-lg p-3 bg-white space-y-1.5">
                      <span className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider leading-none">
                        Materials Markup List
                      </span>
                      {item.materials.map((mc, idx) => (
                        <div key={idx} className="flex justify-between items-center text-[11px]">
                          <span className="text-slate-600 truncate max-w-[130px]">{mc.name}</span>
                          <span className="font-mono text-slate-950 font-medium whitespace-nowrap">
                            ${mc.cost} (+{(mc.margin * 100).toFixed(0)}%)
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Margin Validation Checker */}
                    <div className="border border-slate-150 rounded-lg p-3 bg-slate-900 text-white space-y-1">
                      <div className="flex items-center gap-1.5 text-emerald-400">
                        <Percent className="h-4 w-4 shrink-0" />
                        <span className="text-[10px] font-bold uppercase tracking-widest leading-none">Margin Audit Check</span>
                      </div>
                      <span className="block text-md font-mono font-bold">{item.marginCheck}</span>
                      <span className="text-[9px] text-slate-400 leading-normal block">
                        Estimated Suggested Retail Base: <span className="font-semibold text-slate-100">${suggestedRetailPrice}</span>
                      </span>
                    </div>

                  </div>

                  {/* Risk Parameters flags */}
                  {item.riskFactors.length > 0 && (
                    <div className="flex items-center gap-2 p-2 bg-amber-50 rounded border border-amber-100 rounded-lg">
                      <AlertTriangle className="h-3.5 w-3.5 text-orange-600 shrink-0" />
                      <span className="text-[10px] font-sans font-medium text-amber-900">
                        Risk variables: <span className="font-semibold">{item.riskFactors.join(", ")}</span>
                      </span>
                    </div>
                  )}

                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Custom Price Book Template Builder */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-6 h-fit space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
            <Plus className="h-5 w-5 text-emerald-600" />
            <h3 className="font-semibold text-slate-900">Add Service Template</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 font-sans">
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Template Repair Title
              </label>
              <input
                id="pb-input-name"
                type="text"
                placeholder="e.g. Toilet Flush Valve Replacement"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full text-xs border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-emerald-500 transition"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Category Type
                </label>
                <select
                  id="pb-input-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2.5 focus:outline-emerald-500"
                >
                  <option value="Plumbing">Plumbing</option>
                  <option value="Electrical">Electrical</option>
                  <option value="HVAC">HVAC</option>
                  <option value="Carpentry">Carpentry</option>
                  <option value="Handyman">Handyman</option>
                  <option value="Maintenance">Maintenance</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Minimum Project Base ($)
                </label>
                <input
                  id="pb-input-minprice"
                  type="number"
                  value={minimumPrice}
                  onChange={(e) => setMinimumPrice(parseInt(e.target.value) || 105)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-emerald-500 transition"
                  min={50}
                />
              </div>
            </div>

            {/* Labor block sub-form */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
              <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none border-b border-slate-200/50 pb-1.5">
                Default Labor Block Estimations
              </span>
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Labor Stage Label</label>
                <input
                  id="pb-input-laborname"
                  type="text"
                  placeholder="e.g. Standard diagnostic & install"
                  value={laborName}
                  onChange={(e) => setLaborName(e.target.value)}
                  className="w-full text-[11px] border border-slate-200 bg-white rounded-md p-1.5 focus:outline-emerald-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Est. Hours</label>
                  <input
                    id="pb-input-laborhours"
                    type="number"
                    step="0.25"
                    value={laborHours}
                    onChange={(e) => setLaborHours(parseFloat(e.target.value) || 1)}
                    className="w-full text-[11px] border border-slate-200 bg-white rounded-md p-1.5 focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Hourly Rate ($)</label>
                  <input
                    id="pb-input-laborrate"
                    type="number"
                    value={laborRate}
                    onChange={(e) => setLaborRate(parseInt(e.target.value) || 90)}
                    className="w-full text-[11px] border border-slate-200 bg-white rounded-md p-1.5 focus:outline-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Materials sub-form */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
              <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none border-b border-slate-200/50 pb-1.5">
                Primary Materials Estimates
              </span>
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Material Hardware Label</label>
                <input
                  id="pb-input-materialname"
                  type="text"
                  placeholder="e.g. Fluidmaster fill valves"
                  value={matName}
                  onChange={(e) => setMatName(e.target.value)}
                  className="w-full text-[11px] border border-slate-200 bg-white rounded-md p-1.5 focus:outline-emerald-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">True Unit Cost ($)</label>
                  <input
                    id="pb-input-materialcost"
                    type="number"
                    value={matCost}
                    onChange={(e) => setMatCost(parseInt(e.target.value) || 10)}
                    className="w-full text-[11px] border border-slate-200 bg-white rounded-md p-1.5 focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Margin Markup (e.g. 15%)</label>
                  <input
                    id="pb-input-materialmargin"
                    type="number"
                    step="0.05"
                    value={matMargin}
                    onChange={(e) => setMatMargin(parseFloat(e.target.value) || 0.15)}
                    className="w-full text-[11px] border border-slate-200 bg-white rounded-md p-1.5 focus:outline-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* General Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Customer-Facing Scope Description (Detailed)
              </label>
              <textarea
                id="pb-input-desc"
                rows={3}
                placeholder="Clear description displayed to checking homeowners..."
                value={customerDescription}
                onChange={(e) => setCustomerDescription(e.target.value)}
                className="w-full text-xs border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-emerald-500 resize-none transition"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Foreseeable Risk Factor
              </label>
              <input
                id="pb-input-risk"
                type="text"
                placeholder="e.g. Rotten back mounting studs"
                value={riskFactor}
                onChange={(e) => setRiskFactor(e.target.value)}
                className="w-full text-xs border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-emerald-500 transition"
              />
            </div>

            <button
              id="pb-form-submit-btn"
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-900 font-bold tracking-tight text-sm text-center transition shadow-xs"
            >
              Commit Project Template to Price Book
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
