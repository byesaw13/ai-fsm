import React, { useState } from "react";
import { 
  HeartHandshake, 
  Sparkles, 
  MapPin, 
  Calendar, 
  Clock, 
  CheckCircle, 
  FileText, 
  DollarSign, 
  Bot, 
  Activity, 
  ArrowRight,
  ShieldCheck,
  Check,
  Zap
} from "lucide-react";
import { DatabaseState, Estimate, Invoice, Property } from "../types";

interface ClientPortalProps {
  db: DatabaseState;
  onApproveEstimate: (id: string) => void;
  onPayInvoice: (id: string) => void;
}

export default function ClientPortal({
  db,
  onApproveEstimate,
  onPayInvoice
}: ClientPortalProps) {
  // Let the client toggle which homeowner they are representing to test both states inside the preview frame easily
  const [selectedClientId, setSelectedClientId] = useState<string>("client-1"); // Defaults to Sarah Jenkins

  // Gemini state triggers
  const [reportLoading, setReportLoading] = useState(false);
  const [geminiReport, setGeminiReport] = useState<{
    safetyRating: string;
    overallStatus: string;
    executiveSummary: string;
    actionsList: Array<{ id: string; priority: string; title: string; info: string }>;
  } | null>(null);

  const selectedClient = db.clients.find(c => c.id === selectedClientId);
  const selectedProperty = db.properties.find(p => p.clientId === selectedClientId);
  const selectedMembership = db.memberships.find(m => m.clientId === selectedClientId);

  const upcomingVisits = db.visits.filter(v => v.clientId === selectedClientId && v.status !== "completed");
  const completedVisits = db.visits.filter(v => v.clientId === selectedClientId && v.status === "completed");
  const pendingEstimates = db.estimates.filter(e => e.clientId === selectedClientId && e.status === "sent");
  const outstandingInvoices = db.invoices.filter(i => i.clientId === selectedClientId && i.status === "unpaid");

  // Call the server-side Gemini API endpoint
  const handleGenerateAiReport = async () => {
    if (!selectedProperty) return;
    setReportLoading(true);
    setGeminiReport(null);

    try {
      const response = await fetch("/api/gemini/summarize-home", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          property: selectedProperty,
          membership: selectedMembership,
          historicalTimelines: selectedProperty.timeline
        })
      });

      if (!response.ok) {
        throw new Error("Failed to receive recommendation summary from Express Server.");
      }

      const report = await response.json();
      setGeminiReport(report);
    } catch (e) {
      console.error("Gemini reporting diagnostic client failure:", e);
    } finally {
      setReportLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans" id="client-portal-view">
      
      {/* Simulation Selector Bar */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">Simulator Client Account Switcher</span>
          <h3 className="text-white text-sm font-semibold mt-1">Simulate portal experience for:</h3>
        </div>
        <div className="flex gap-2">
          {db.clients.map(c => (
            <button
               id={`switch-client-btn-${c.id}`}
              key={c.id}
              onClick={() => {
                setSelectedClientId(c.id);
                setGeminiReport(null);
              }}
              className={`py-1.5 px-4 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                selectedClientId === c.id 
                  ? "bg-emerald-500 text-slate-900" 
                  : "bg-slate-800 text-slate-300 hover:bg-slate-755"
              }`}
            >
              {c.name} ({db.properties.find(p => p.clientId === c.id)?.address.split(",")[0]})
            </button>
          ))}
        </div>
      </div>

      {/* Main portal header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Home Care Portal</h2>
          <p className="text-sm text-slate-500 flex items-center gap-1.5">
            <MapPin className="h-4.5 w-4.5 text-emerald-600 mt-0.5 shrink-0" />
            <span>Welcome back, <span className="font-semibold text-slate-800">{selectedClient?.name}</span> • Managed Site: {selectedProperty?.address}</span>
          </p>
        </div>

        {selectedMembership ? (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4 flex items-center gap-3 md:w-80 shrink-0">
            <HeartHandshake className="h-10 w-10 text-emerald-600 shrink-0" />
            <div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-emerald-700 leading-none block">Prevention Subscription</span>
              <span className="text-sm font-bold text-slate-900">{selectedMembership.tier.toUpperCase()} CARE ACTIVE</span>
              <p className="text-[10px] text-slate-500 font-sans mt-0.5">Recurring safety inspections configured and managed.</p>
            </div>
          </div>
        ) : (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-500 font-sans shrink-0">
            No active Membership Plan associated. Enroll in a monthly plan to enable recurring audits.
          </div>
        )}
      </div>

      {/* Grid: Upcoming Visits & Action Requests */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Hand: Operations schedule and Billings */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Section 1: Upcoming Maintenance Checks */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                <Calendar className="h-4.5 w-4.5 text-emerald-600" />
                <span>Upcoming Visits & Safe Audits</span>
              </h3>
            </div>
            
            <div className="divide-y divide-slate-100">
              {upcomingVisits.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No upcoming maintenance work scheduled. Request a visit using our intakes form.
                </div>
              ) : (
                upcomingVisits.map(visit => (
                  <div key={visit.id} className="p-5 flex items-start justify-between font-sans">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono leading-none bg-slate-150 px-2 py-0.5 rounded text-slate-500 font-bold">
                          {visit.timeSlot}
                        </span>
                        <span className="text-xs text-slate-400">{visit.date}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900">
                        Preventative seasonal check with {visit.techName}
                      </h4>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">{visit.notes}</p>
                    </div>

                    <span className="text-[10px] inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-105 uppercase font-bold text-blue-700 border border-blue-200 shrink-0">
                      Dispatched
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Section 2: Estimates Pending Your Signature Approval */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                <FileText className="h-4.5 w-4.5 text-indigo-600" />
                <span>Estimates Awaiting Approval</span>
              </h3>
            </div>
            
            <div className="divide-y divide-slate-100">
              {pendingEstimates.length === 0 ? (
                <div className="p-6 text-center text-slate-400 text-xs font-sans">
                  No estimates awaiting signature. Clear for now.
                </div>
              ) : (
                pendingEstimates.map(est => (
                  <div key={est.id} className="p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-400">Estimate ID: {est.id}</span>
                      <span className="text-sm font-bold text-slate-950 font-mono">${est.total}</span>
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-900">{est.title}</h4>
                      <p className="text-xs text-slate-500 leading-relaxed italic">Notes from advisor: "{est.notes}"</p>
                    </div>

                    {/* Breakdown of items */}
                    <div className="bg-slate-50 border border-slate-100 rounded-lg divide-y divide-slate-200/60 p-3 text-xs shrink-0">
                      {est.items.map((item, idx) => (
                        <div key={idx} className="py-2 flex items-center justify-between">
                          <div>
                            <h5 className="font-semibold text-slate-800">{item.name}</h5>
                            <p className="text-[10px] text-slate-400">{item.description}</p>
                          </div>
                          <span className="font-mono text-slate-700 whitespace-nowrap shrink-0">{item.quantity}x @ ${item.price}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-end pt-2 shrink-0">
                      <button
                        id={`client-approve-est-btn-${est.id}`}
                        onClick={() => onApproveEstimate(est.id)}
                        className="py-2.5 px-6 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                      >
                        <Check className="h-4 w-4" /> Approve & Authorize Repair Visits
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Section 3: Invoices/Payment status */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                <DollarSign className="h-4.5 w-4.5 text-emerald-600" />
                <span>Outstanding Invoices / Accounts</span>
              </h3>
            </div>
            
            <div className="divide-y divide-slate-100">
              {outstandingInvoices.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No invoices are due at this time. Thank you for your business.
                </div>
              ) : (
                outstandingInvoices.map(inv => (
                  <div key={inv.id} className="p-5 flex items-center justify-between font-sans">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-slate-400">Invoice #{inv.id}</span>
                        <span className="text-[10px] bg-red-50 text-red-700 font-semibold px-2 py-0.5 rounded border border-red-150">
                          Due {inv.dueDate}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900">{inv.title}</h4>
                      <p className="text-xs text-slate-500 font-sans">Fulfillment completed on route stop.</p>
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      <span className="text-sm font-bold text-slate-900 font-mono">${inv.total}</span>
                      <button
                        id={`client-pay-inv-${inv.id}`}
                        onClick={() => onPayInvoice(inv.id)}
                        className="py-1.5 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-xs font-bold transition"
                      >
                        Pay Invoice
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

        {/* Right Hand Side: AI Preventive Advisor Platform Intelligence */}
        <div className="space-y-8">
          
          <div className="bg-slate-950 text-white border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="flex items-center gap-2.5 border-b border-slate-800 pb-4">
              <Bot className="h-6 w-6 text-emerald-400 animate-pulse" />
              <div>
                <h3 className="font-semibold text-white tracking-tight">AI Home intelligence</h3>
                <span className="text-[9px] font-mono tracking-widest text-emerald-400 uppercase font-bold leading-none">Gemini Predictive Care</span>
              </div>
            </div>

            <p className="text-xs text-slate-350 leading-relaxed font-sans">
              Dovetails Services leverages advanced Gemini models on the server to read property assets, historical repairs, and technical findings, compiling regular **Home Care Reports** for clients to prevent leaks or dry-rots.
            </p>

            <button
              id="gemini-trigger-btn"
              onClick={handleGenerateAiReport}
              disabled={reportLoading}
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-900 font-bold text-xs transition flex items-center justify-center gap-2 font-sans"
            >
              {reportLoading ? (
                <>
                  <div className="h-4 w-4 rounded-full border-2 border-slate-950 border-t-transparent animate-spin shrink-0"></div>
                  <span>Analyzing House Blueprint...</span>
                </>
              ) : (
                <>
                  <Zap className="h-4.5 w-4.5 fill-current" />
                  <span>Analyze My Home Health Safety with Gemini API</span>
                </>
              )}
            </button>

            {/* Generated Gemini recommendation block */}
            {geminiReport && (
              <div className="space-y-4 pt-4 border-t border-slate-800 animate-fade-in text-xs leading-normal font-sans">
                
                {/* Score badge */}
                <div className="flex justify-between items-center bg-slate-900 border border-slate-800 p-3 rounded-xl">
                  <div>
                    <span className="text-[9px] text-slate-405 uppercase font-bold tracking-widest block leading-none mb-1">Preventive Health Rating</span>
                    <span className="block text-md font-semibold text-emerald-400">{geminiReport.overallStatus}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-mono font-bold text-white leading-none">{geminiReport.safetyRating}</span>
                  </div>
                </div>

                {/* Executive text summary */}
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-widest block font-bold mb-1">Executive Care Diagnostics</span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {geminiReport.executiveSummary}
                  </p>
                </div>

                {/* Action priorities */}
                <div className="space-y-2 pt-2 shrink-0">
                  <span className="text-[9px] text-slate-400 uppercase tracking-widest block font-bold leading-none">Preventive Action Items</span>
                  <div className="space-y-2">
                    {geminiReport.actionsList.map((act) => (
                      <div key={act.id} className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded leading-none ${
                            act.priority === "HIGH" 
                              ? "bg-red-500 text-white" 
                              : act.priority === "MEDIUM" 
                              ? "bg-amber-500 text-slate-900" 
                              : "bg-blue-500 text-white"
                          }`}>
                            {act.priority}
                          </span>
                          <span className="font-bold text-slate-200 text-xs">{act.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-sans leading-normal">{act.info}</p>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}
          </div>

          {/* Snapshot listing */}
          {selectedProperty && selectedProperty.snapshots.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 shadow-xs">
              <h4 className="font-bold text-xs uppercase tracking-wide text-slate-800 border-b border-slate-150 pb-2">
                Condition snapshot grades
              </h4>
              <div className="space-y-2.5">
                {selectedProperty.snapshots.map(sn => (
                  <div key={sn.id} className="p-3 bg-slate-50 border border-slate-100 rounded-lg flex items-start gap-3">
                    <div className="h-8 w-8 rounded bg-emerald-100 text-slate-900 font-mono font-bold text-sm flex items-center justify-center shrink-0">
                      {sn.grade}
                    </div>
                    <div>
                      <h5 className="text-xs font-bold text-slate-805 leading-none">{sn.sectionName}</h5>
                      <p className="text-[10px] text-slate-400 font-mono mt-1">Inspected on {sn.date}</p>
                      <p className="text-[11px] text-slate-600 mt-1 font-sans leading-relaxed">{sn.details}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
