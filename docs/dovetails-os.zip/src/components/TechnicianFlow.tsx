import React, { useState } from "react";
import { 
  Wrench, 
  MapPin, 
  Phone, 
  Clock, 
  CheckSquare, 
  Square, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  Check, 
  Navigation,
  Sparkles,
  Home
} from "lucide-react";
import { DatabaseState, Visit, IssueFound, MaterialUsed } from "../types";

interface TechnicianFlowProps {
  db: DatabaseState;
  onUpdateVisitStatus: (id: string, status: Visit["status"], notes?: string, materialsUsed?: MaterialUsed[]) => void;
  onToggleChecklist: (visitId: string, itemId: string) => void;
  onAddFinding: (visitId: string, finding: IssueFound) => void;
}

export default function TechnicianFlow({
  db,
  onUpdateVisitStatus,
  onToggleChecklist,
  onAddFinding
}: TechnicianFlowProps) {
  const [selectedVisitId, setSelectedVisitId] = useState<string | null>(null);
  
  // Local checklist notes
  const [techNotes, setTechNotes] = useState("");
  
  // Local finding creator states
  const [findingCategory, setFindingCategory] = useState("Preventative");
  const [findingDesc, setFindingDesc] = useState("");
  const [findingSev, setFindingSev] = useState<"low" | "medium" | "high">("medium");
  const [findingRec, setFindingRec] = useState("");

  // Material adder
  const [matName, setMatName] = useState("");
  const [matQty, setMatQty] = useState(1);
  const [materialsList, setMaterialsList] = useState<MaterialUsed[]>([]);

  const todayVisits = db.visits.filter(v => v.date === "2026-05-24");
  const activeVisit = db.visits.find(v => v.id === selectedVisitId);

  // Initialize notes inside state when visit selected
  React.useEffect(() => {
    if (activeVisit) {
      setTechNotes(activeVisit.notes || "");
      setMaterialsList(activeVisit.materialsUsed || []);
    }
  }, [selectedVisitId, activeVisit]);

  const handleAddFindingForm = (e: React.FormEvent, visitId: string) => {
    e.preventDefault();
    if (!findingDesc.trim() || !findingRec.trim()) return;

    onAddFinding(visitId, {
      category: findingCategory,
      description: findingDesc,
      severity: findingSev,
      recommendedAction: findingRec
    });

    setFindingDesc("");
    setFindingRec("");
  };

  const handleAddMaterial = () => {
    if (!matName.trim()) return;
    setMaterialsList([...materialsList, { name: matName, qty: matQty }]);
    setMatName("");
    setMatQty(1);
  };

  const handleRemoveMaterial = (index: number) => {
    setMaterialsList(materialsList.filter((_, idx) => idx !== index));
  };

  return (
    <div className="space-y-6 animate-fade-in" id="technician-flow-view">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Handyman Field Dashboard</h2>
        <p className="text-sm text-slate-500 mt-1 font-sans">
          Logged in: <span className="font-semibold text-slate-800">Bob Miller</span> (Lead Technician, Dovetails OS)
        </p>
      </div>

      {!activeVisit ? (
        /* ROUTE OVERVIEW SCREEN */
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Clock className="h-5 w-5 text-slate-500" />
            <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wide">Today's Visits & Route</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {todayVisits.length === 0 ? (
              <div className="md:col-span-2 bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400">
                <Home className="h-10 w-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">No scheduled route stops today.</p>
              </div>
            ) : (
              todayVisits.map(visit => {
                const client = db.clients.find(c => c.id === visit.clientId);
                const property = db.properties.find(p => p.id === visit.propertyId);

                return (
                  <div
                    id={`tech-visit-row-${visit.id}`}
                    key={visit.id}
                    onClick={() => setSelectedVisitId(visit.id)}
                    className="p-5 bg-white border border-slate-200 rounded-xl hover:border-emerald-500 cursor-pointer shadow-xs hover:shadow-sm transition font-sans flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                          {visit.timeSlot}
                        </span>
                        
                        {visit.status === "completed" ? (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                            ✓ Complete
                          </span>
                        ) : visit.status === "arrived" ? (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full animate-pulse">
                            ● Active
                          </span>
                        ) : visit.status === "on_way" ? (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full">
                            ⚡ On My Way
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
                            Scheduled
                          </span>
                        )}
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-md font-bold text-slate-900">
                          {client ? client.name : "N/A"}
                        </h4>
                        <p className="text-xs text-slate-500 flex items-start gap-1">
                          <MapPin className="h-4 w-4 shrink-0 text-slate-400" />
                          <span>{property ? property.address : "No address specified"}</span>
                        </p>
                      </div>

                      {/* Brief description of task scope items */}
                      <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded border border-slate-100 leading-normal">
                        Scope tasks: {visit.checklist.map(c => c.task.replace("Fulfill/Install: ", "")).join(" • ")}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between font-mono text-[10px] text-slate-400 font-medium shrink-0">
                      <span>Ref ID: {visit.id}</span>
                      <span className="text-emerald-600 font-bold hover:underline flex items-center gap-0.5">
                        <span>Open visit panel</span>
                        <Check className="h-3 w-3" />
                      </span>
                    </div>

                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        /* ACTIVE BRUTALLY SIMPLE TECHNICIAN COMPLETED visit WORKFLOW */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12">
          
          <div className="lg:col-span-2 space-y-6">
            {/* Active Visit card header */}
            <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-xs space-y-4">
              <button
                id="tech-back-btn"
                onClick={() => setSelectedVisitId(null)}
                className="text-xs font-bold text-slate-500 hover:text-slate-900 border border-slate-200 py-1 px-3 rounded bg-white"
              >
                ← Back to Today's route Stops
              </button>

              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] font-mono bg-slate-150 py-0.5 px-1.5 rounded text-slate-500 font-bold">
                    Visit stop #{activeVisit.id}
                  </span>
                  <p className="text-xs text-slate-400 mt-1 font-mono font-medium">Scheduled for {activeVisit.timeSlot}</p>
                </div>
                
                {/* Status controllers buttons */}
                <div className="flex flex-wrap gap-2 shrink-0">
                  {activeVisit.status === "scheduled" && (
                    <button
                      id="tech-btn-onway"
                      onClick={() => onUpdateVisitStatus(activeVisit.id, "on_way")}
                      className="px-3.5 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 font-bold text-xs text-white flex items-center gap-1.5 transition"
                    >
                      <Navigation className="h-3.5 w-3.5" /> Set Status: On My Way
                    </button>
                  )}

                  {activeVisit.status === "on_way" && (
                    <button
                      id="tech-btn-arrived"
                      onClick={() => onUpdateVisitStatus(activeVisit.id, "arrived")}
                      className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 font-bold text-xs text-white flex items-center gap-1.5 transition"
                    >
                      <Wrench className="h-3.5 w-3.5 animate-pulse" /> Confirm Arrival at site
                    </button>
                  )}

                  {activeVisit.status === "completed" ? (
                    <span className="p-1.5 bg-emerald-50 text-emerald-800 rounded font-bold text-xs border border-emerald-200">
                      ✓ Completed Visit
                    </span>
                  ) : activeVisit.status === "arrived" ? (
                    <span className="p-1.5 bg-indigo-50 text-indigo-800 rounded font-bold text-xs">
                      ● Active Working State
                    </span>
                  ) : (
                    <span className="p-1.5 bg-slate-50 text-slate-500 rounded font-bold text-xs border border-slate-200">
                      Transition to 'On My Way' first
                    </span>
                  )}
                </div>
              </div>

              {/* Home site spec cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-2 text-xs font-sans">
                <div className="space-y-1 bg-slate-50 rounded-lg p-3">
                  <span className="block text-[9px] font-semibold text-slate-400 uppercase tracking-widest leading-none">
                    Homeowner
                  </span>
                  <h4 className="text-sm font-bold text-slate-900">
                    {db.clients.find(c => c.id === activeVisit.clientId)?.name}
                  </h4>
                  <p className="text-slate-600 flex items-center gap-1 leading-none mt-1">
                    <Phone className="h-3.5 w-3.5 text-slate-400" />
                    <span>{db.clients.find(c => c.id === activeVisit.clientId)?.phone}</span>
                  </p>
                </div>

                <div className="space-y-1 bg-slate-50 rounded-lg p-3">
                  <span className="block text-[9px] font-semibold text-slate-400 uppercase tracking-widest leading-none">
                    Job Address
                  </span>
                  <p className="text-slate-600 flex items-start gap-1 leading-tight mt-1 font-medium">
                    <MapPin className="h-3.5 w-3.5 text-emerald-600 mt-0.5 resize-none shrink-0" />
                    <span>{db.properties.find(p => p.id === activeVisit.propertyId)?.address}</span>
                  </p>
                </div>
              </div>

              {/* Task list checklists */}
              <div className="space-y-3 pt-2 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-slate-150 pb-2">
                  <CheckSquare className="h-5 w-5 text-emerald-600" />
                  <h4 className="font-bold text-xs uppercase tracking-wide text-slate-800 leading-none">
                    Service checklist items
                  </h4>
                </div>
                
                <div className="divide-y divide-slate-150">
                  {activeVisit.checklist.map(chk => (
                    <div
                      id={`chk-row-${chk.id}`}
                      key={chk.id}
                      onClick={() => onToggleChecklist(activeVisit.id, chk.id)}
                      className="py-3 flex items-start gap-3 cursor-pointer select-none transition hover:bg-slate-50/50"
                    >
                      {chk.completed ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                      ) : (
                        <div className="h-5 w-5 rounded border border-slate-300 bg-white shrink-0 mt-0.5" />
                      )}
                      <span className={`text-xs ${chk.completed ? "text-slate-400 line-through" : "text-slate-700 font-medium"}`}>
                        {chk.task}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Evidence logging panel: added findings and materials */}
            <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-xs space-y-6">
              
              {/* Materials Adder */}
              <div className="space-y-4 shrink-0">
                <h4 className="font-bold text-xs uppercase tracking-wide text-slate-800 border-b border-slate-150 pb-2">
                  Materials / Hardware Used
                </h4>

                <div className="flex gap-2 shrink-0">
                  <input
                    id="tech-mat-name"
                    type="text"
                    placeholder="e.g. 12AWG copper pigtail"
                    value={matName}
                    onChange={(e) => setMatName(e.target.value)}
                    className="flex-1 text-xs border border-slate-200 bg-slate-50 p-2 rounded-lg"
                  />
                  <input
                    id="tech-mat-qty"
                    type="number"
                    value={matQty}
                    onChange={(e) => setMatQty(parseInt(e.target.value) || 1)}
                    className="w-16 text-center text-xs border border-slate-200 bg-slate-50 p-2 rounded-lg select-all"
                    min="1"
                  />
                  <button
                    id="tech-mat-add-btn"
                    type="button"
                    onClick={handleAddMaterial}
                    className="py-2 px-3 rounded-lg bg-slate-900 text-white hover:bg-slate-800 text-xs font-bold transition flex items-center gap-1.5"
                  >
                    <Plus className="h-4.5 w-4.5" /> Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 text-xs font-mono">
                  {materialsList.map((mat, idx) => (
                    <span key={idx} className="inline-flex items-center gap-1.5 rounded-md bg-slate-100 px-2.5 py-1 text-xs text-slate-700">
                      <span>{mat.qty}x {mat.name}</span>
                      <button
                        id={`tech-mats-remove-${idx}`}
                        type="button"
                        onClick={() => handleRemoveMaterial(idx)}
                        className="text-slate-400 hover:text-red-500 ml-1 font-bold leading-none select-none text-[12px]"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                  {materialsList.length === 0 && (
                    <span className="text-xs text-slate-400 italic">No hardware added yet in route stop.</span>
                  )}
                </div>
              </div>

              {/* Technician active Notes input */}
              <div className="space-y-2 shrink-0">
                <h4 className="font-bold text-xs uppercase tracking-wide text-slate-800 border-b border-slate-150 pb-2">
                  Technician service Notes
                </h4>
                <textarea
                  id="tech-notes-area"
                  rows={3}
                  placeholder="Record what you observed, measurements, torques, etc..."
                  value={techNotes}
                  onChange={(e) => setTechNotes(e.target.value)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-indigo-500 resize-none transition"
                />
              </div>

              {/* Complete visit check submission card */}
              {activeVisit.status !== "completed" && (
                <div className="pt-4 border-t border-slate-150 flex items-center justify-end shrink-0">
                  <button
                    id="tech-checkout-btn"
                    onClick={() => onUpdateVisitStatus(activeVisit.id, "completed", techNotes, materialsList)}
                    disabled={activeVisit.status !== "arrived"}
                    className={`py-3 px-6 rounded-xl font-bold text-sm tracking-tight shadow-xs transition ${
                      activeVisit.status === "arrived"
                        ? "bg-emerald-500 hover:bg-emerald-600 text-white"
                        : "bg-slate-150 text-slate-400 cursor-not-allowed border border-slate-200"
                    }`}
                  >
                    Submit Completed Visit & Checkout
                  </button>
                </div>
              )}

            </div>
          </div>

          {/* Right Hand: On-Site Finding Logger (abides by local role requirements) */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 h-fit space-y-6">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              <h3 className="font-semibold text-slate-900 text-sm">On-Site Safety finding</h3>
            </div>

            <form onSubmit={(e) => handleAddFindingForm(e, activeVisit.id)} className="space-y-4 text-xs font-sans font-medium">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1">
                  Hazard Category
                </label>
                <select
                  id="tech-finding-category"
                  value={findingCategory}
                  onChange={(e) => setFindingCategory(e.target.value)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 p-2 rounded-lg"
                >
                  <option value="Preventative">Preventative Care (e.g. cleaning)</option>
                  <option value="Electrical">Electrical Safety Hazard</option>
                  <option value="Plumbing">Plumbing Leaks/Molds</option>
                  <option value="Structural">Structural Wear/Railing</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1">
                  Severity Threshold
                </label>
                <div className="grid grid-cols-3 gap-1">
                  {(["low", "medium", "high"] as const).map(sev => (
                    <button
                      id={`tech-finding-sev-${sev}`}
                      key={sev}
                      type="button"
                      onClick={() => setFindingSev(sev)}
                      className={`py-1.5 rounded-lg border text-center uppercase text-[9px] font-bold ${
                        findingSev === sev 
                          ? sev === "high" 
                            ? "bg-red-500 border-red-500 text-white" 
                            : sev === "medium" 
                            ? "bg-amber-500 border-amber-500 text-white" 
                            : "bg-blue-500 border-blue-500 text-white"
                          : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-600"
                      }`}
                    >
                      {sev}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1">
                  Specific Observation <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="tech-finding-desc"
                  rows={2}
                  placeholder="Tripping GFCI, dry rot on floor rim..."
                  value={findingDesc}
                  onChange={(e) => setFindingDesc(e.target.value)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2 focus:outline-amber-400 resize-none transition"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1">
                  Recommended action <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="tech-finding-rec"
                  rows={2}
                  placeholder="Replace with weather-resistant GFCI..."
                  value={findingRec}
                  onChange={(e) => setFindingRec(e.target.value)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 rounded-lg p-2 focus:outline-amber-400 resize-none transition"
                  required
                />
              </div>

              <button
                id="tech-finding-submit-btn"
                type="submit"
                className="w-full py-2.5 px-3 rounded-lg bg-orange-500 hover:bg-orange-600 font-bold font-sans text-xs text-slate-950 flex items-center justify-center gap-1.5 transition"
              >
                <Plus className="h-4.5 w-4.5" /> Log Observation
              </button>
            </form>

            <div className="pt-4 border-t border-slate-150 space-y-2 shrink-0">
              <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider leading-none">
                Logged Observations ({activeVisit.issuesFound.length})
              </span>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {activeVisit.issuesFound.map((f, idx) => (
                  <div key={idx} className="p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[9px] font-bold text-red-600 uppercase font-mono">{f.severity}</span>
                      <span className="text-[9px] text-slate-400 uppercase font-mono leading-none">{f.category}</span>
                    </div>
                    <p className="text-slate-700 leading-snug">{f.description}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
