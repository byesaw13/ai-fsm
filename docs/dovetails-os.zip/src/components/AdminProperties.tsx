import React, { useState } from "react";
import { 
  Home, 
  Search, 
  MapPin, 
  Wrench, 
  Calendar, 
  FolderLock, 
  HeartHandshake, 
  AlertTriangle, 
  Plus, 
  FileText, 
  History, 
  Activity,
  Layers,
  CheckCircle2,
  Lock
} from "lucide-react";
import { DatabaseState, Property, OpenIssue, HomeAsset, PropertyVaultItem, TimelineEvent } from "../types";
import Drawer from "./Drawer";

interface AdminPropertiesProps {
  db: DatabaseState;
  onToggleIssue: (propId: string, issueId: string) => void;
  onAddAsset: (propId: string, asset: Omit<HomeAsset, "id">) => void;
  onAddVaultItem: (propId: string, item: Omit<PropertyVaultItem, "id">) => void;
  onBuildEstimateFromIssue: (propertyId: string, issue: OpenIssue) => void;
}

export default function AdminProperties({
  db,
  onToggleIssue,
  onAddAsset,
  onAddVaultItem,
  onBuildEstimateFromIssue
}: AdminPropertiesProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [drawerTab, setDrawerTab] = useState<"blueprint" | "timeline" | "findings" | "vault">("blueprint");

  // Inputs for Drawer Subsystem Creator Forms (Blueprint Add)
  const [newAssetName, setNewAssetName] = useState("");
  const [newAssetBrand, setNewAssetBrand] = useState("");
  const [newAssetYear, setNewAssetYear] = useState(2020);
  const [newAssetStatus, setNewAssetStatus] = useState<"good" | "warning" | "replace">("good");

  // Inputs for Drawer Manuals Selector Forms (Vault Add)
  const [newVaultTitle, setNewVaultTitle] = useState("");
  const [newVaultCategory, setNewVaultCategory] = useState("HVAC / Mechanical");
  const [newVaultDesc, setNewVaultDesc] = useState("");

  const filteredProperties = db.properties.filter(prop => {
    const client = db.clients.find(c => c.id === prop.clientId);
    const textStr = `${prop.address} ${client?.name || ""} ${prop.propertyType}`.toLowerCase();
    return textStr.includes(searchTerm.toLowerCase());
  });

  const selectedProperty = db.properties.find(p => p.id === selectedPropertyId);
  const selectedClient = selectedProperty ? db.clients.find(c => c.id === selectedProperty.clientId) : null;
  const selectedMembership = selectedProperty ? db.memberships.find(m => m.propertyId === selectedProperty.id) : null;

  // Drawer asset submittal handler
  const handleAddAssetSubmit = (e: React.FormEvent, propId: string) => {
    e.preventDefault();
    if (!newAssetName.trim()) return;
    onAddAsset(propId, {
      name: newAssetName,
      brand: newAssetBrand || "Generic brand",
      installedYear: newAssetYear || 2020,
      status: newAssetStatus
    });
    setNewAssetName("");
    setNewAssetBrand("");
  };

  // Drawer vault submittal handler
  const handleAddVaultSubmit = (e: React.FormEvent, propId: string) => {
    e.preventDefault();
    if (!newVaultTitle.trim()) return;
    onAddVaultItem(propId, {
      title: newVaultTitle,
      category: newVaultCategory,
      description: newVaultDesc,
      dateAdded: new Date().toISOString().split("T")[0]
    });
    setNewVaultTitle("");
    setNewVaultDesc("");
  };

  return (
    <div className="space-y-6 animate-fade-in" id="admin-properties-view">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Home Intelligence Vault</h2>
          <p className="text-sm text-slate-500 mt-1 font-sans">
            Review detailed physical home records, asset models, timeline histories, and safety snapshots.
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-80 shrink-0">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <input
            id="property-search-input"
            type="text"
            placeholder="Search by address, system, client name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-sm border border-slate-200 rounded-lg pl-9 pr-4 py-2 bg-white focus:outline-emerald-500 hover:border-slate-300 transition"
          />
        </div>
      </div>

      {/* Grid of Properties */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProperties.length === 0 ? (
          <div className="md:col-span-2 bg-white border border-slate-200 rounded-xl p-16 text-center text-slate-400">
            <Home className="h-12 w-12 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">No properties located</p>
            <p className="text-xs text-slate-500 mt-1">Make sure you have converted booking requests to generate home records.</p>
          </div>
        ) : (
          filteredProperties.map(prop => {
            const client = db.clients.find(c => c.id === prop.clientId);
            const activeIssues = prop.openIssues.filter(i => !i.resolved);
            const activeMem = db.memberships.find(m => m.propertyId === prop.id);

            return (
              <div
                id={`property-card-${prop.id}`}
                key={prop.id}
                onClick={() => {
                  setSelectedPropertyId(prop.id);
                  setDrawerTab("blueprint");
                }}
                className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden cursor-pointer hover:border-emerald-500 hover:shadow-sm transition flex flex-col justify-between"
              >
                {/* Header info */}
                <div className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-slate-400">
                      Home Record
                    </span>
                    
                    {activeMem ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                        <HeartHandshake className="h-3 w-3" /> {activeMem.tier} Subscriber
                      </span>
                    ) : (
                      <span className="text-[10px] font-medium text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                        No Membership Plan
                      </span>
                    )}
                  </div>

                  <div className="space-y-1 z-10">
                    <h3 className="text-lg font-semibold text-slate-900 leading-tight flex items-start gap-1.5">
                      <MapPin className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{prop.address}</span>
                    </h3>
                    <p className="text-xs text-slate-500 ml-6">
                      Owner: <span className="font-semibold text-slate-700">{client ? client.name : "N/A"}</span> • Year Built {prop.yearBuilt}
                    </p>
                  </div>

                  {/* Open Findings Alert summary */}
                  {activeIssues.length > 0 && (
                    <div className="flex items-start gap-2 p-2.5 bg-red-50 border border-red-100 rounded-lg text-red-800 ml-6">
                      <AlertTriangle className="h-4 w-4 shrink-0 text-red-500 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold">{activeIssues.length} Unresolved Hazard Findings</p>
                        <p className="text-[10px] text-red-700 leading-normal font-sans text-ellipsis line-clamp-1">{activeIssues[0].description}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer KPI ribbon */}
                <div className="grid grid-cols-3 border-t border-slate-100 divide-x divide-slate-100 bg-slate-50 text-center text-xs py-3.5 px-2">
                  <div className="flex flex-col font-sans">
                    <span className="font-mono font-bold text-slate-950">{prop.assets.length}</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Systems Listed</span>
                  </div>
                  <div className="flex flex-col font-sans">
                    <span className="font-mono font-bold text-slate-950">{prop.timeline.length}</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Timeline Log</span>
                  </div>
                  <div className="flex flex-col font-sans mb-0">
                    <span className="font-mono font-bold text-slate-950">{prop.vault.length}</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Docs Guarded</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Polish Drawer populated with multi-concern tabs */}
      {selectedProperty && (
        <Drawer
          isOpen={selectedPropertyId !== null}
          onClose={() => setSelectedPropertyId(null)}
          title={`Property: ${selectedProperty.address.split(",")[0]}`}
          contextLine={`Home OS Reference #${selectedProperty.id} • Owned by ${selectedClient ? selectedClient.name : "Default"}`}
          footer={
            <div className="flex items-center justify-between w-full shrink-0">
              <span className="text-[10px] font-mono text-slate-400">Dovetails OS • Secure Home Records</span>
              <button
                id="drawer-footer-dismiss-btn"
                onClick={() => setSelectedPropertyId(null)}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 text-xs font-semibold"
              >
                Dismiss View
              </button>
            </div>
          }
        >
          {/* Sub Navigation Inside Drawer */}
          <div className="flex border-b border-slate-100 -mx-6 px-6 pb-2 mb-6 shrink-0 z-20">
            <div className="flex gap-4">
              <button
                id="drawer-subtab-blueprint"
                onClick={() => setDrawerTab("blueprint")}
                className={`text-xs font-bold uppercase tracking-wider pb-2 border-b-2 transition ${
                  drawerTab === "blueprint" ? "border-emerald-500 text-emerald-600" : "border-transparent text-slate-500 hover:text-slate-900"
                }`}
              >
                Blueprints & Systems
              </button>
              <button
                id="drawer-subtab-timeline"
                onClick={() => setDrawerTab("timeline")}
                className={`text-xs font-bold uppercase tracking-wider pb-2 border-b-2 transition ${
                  drawerTab === "timeline" ? "border-emerald-500 text-emerald-600" : "border-transparent text-slate-500 hover:text-slate-900"
                }`}
              >
                timeline Log
              </button>
              <button
                id="drawer-subtab-findings"
                onClick={() => setDrawerTab("findings")}
                className={`text-xs font-bold uppercase tracking-wider pb-2 border-b-2 transition ${
                  drawerTab === "findings" ? "border-emerald-500 text-emerald-600" : "border-transparent text-slate-500 hover:text-slate-900"
                }`}
              >
                Active Findings
              </button>
              <button
                id="drawer-subtab-vault"
                onClick={() => setDrawerTab("vault")}
                className={`text-xs font-bold uppercase tracking-wider pb-2 border-b-2 transition ${
                  drawerTab === "vault" ? "border-emerald-500 text-emerald-600" : "border-transparent text-slate-500 hover:text-slate-900"
                }`}
              >
                Document VAULT
              </button>
            </div>
          </div>

          {/* TAB CONTENT PANELS */}

          {/* Tab 1: Blueprint */}
          {drawerTab === "blueprint" && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-3">
                <div className="flex items-center justify-between shrink-0">
                  <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
                    <Wrench className="h-4.5 w-4.5 text-slate-500" />
                    <span>Resident Systems & Equipment</span>
                  </h4>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {selectedProperty.assets.map(asset => (
                    <div key={asset.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                      <div>
                        <h5 className="text-xs font-bold text-slate-700">{asset.name}</h5>
                        <p className="text-xs text-slate-500 font-sans mt-0.5">Brand: {asset.brand} • Installed {asset.installedYear}</p>
                      </div>
                      <span className={`text-[9px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full ${
                        asset.status === "good" 
                          ? "bg-emerald-100 text-emerald-800" 
                          : asset.status === "warning" 
                          ? "bg-amber-100 text-amber-800" 
                          : "bg-red-100 text-red-800"
                      }`}>
                        {asset.status} Check
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add System Asset Form (abides by Labels Above Fields form rule) */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                <h5 className="text-xs font-bold text-slate-800 uppercase tracking-widest border-b border-slate-200 pb-2">
                  Log New Home System / Appliance
                </h5>
                <form onSubmit={(e) => handleAddAssetSubmit(e, selectedProperty.id)} className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                      System Name
                    </label>
                    <input
                      id="asset-form-name"
                      type="text"
                      placeholder="e.g. Bradford White 50-Gal Gas Boiler"
                      value={newAssetName}
                      onChange={(e) => setNewAssetName(e.target.value)}
                      className="w-full text-xs border border-slate-200 bg-white rounded-md p-2 focus:outline-emerald-500"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                        Brand/Model
                      </label>
                      <input
                        id="asset-form-brand"
                        type="text"
                        placeholder="e.g. Model RG150T"
                        value={newAssetBrand}
                        onChange={(e) => setNewAssetBrand(e.target.value)}
                        className="w-full text-xs border border-slate-200 bg-white rounded-md p-2 focus:outline-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                        Install Year
                      </label>
                      <input
                        id="asset-form-year"
                        type="number"
                        value={newAssetYear}
                        onChange={(e) => setNewAssetYear(parseInt(e.target.value) || 2020)}
                        className="w-full text-xs border border-slate-200 bg-white rounded-md p-2 focus:outline-emerald-500"
                        min={1950}
                        max={2026}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                      Initial Physical Condition status
                    </label>
                    <select
                      id="asset-form-status"
                      value={newAssetStatus}
                      onChange={(e) => setNewAssetStatus(e.target.value as any)}
                      className="w-full text-xs border border-slate-200 bg-white p-2 rounded-md focus:outline-emerald-500"
                    >
                      <option value="good">Good Condition - Optimal Performance</option>
                      <option value="warning">Warning status - Wear & Age Evident</option>
                      <option value="replace">Urgent - Replacement Recommended</option>
                    </select>
                  </div>

                  <button
                    id="asset-form-submit-btn"
                    type="submit"
                    className="w-full py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-xs font-bold transition flex items-center justify-center gap-1.5"
                  >
                    <Plus className="h-4 w-4" /> Add Asset systems
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Tab 2: Timeline Log */}
          {drawerTab === "timeline" && (
            <div className="space-y-6 animate-fade-in">
              <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
                <History className="h-4.5 w-4.5 text-slate-500" />
                <span>Permanent Home Care History</span>
              </h4>

              <div className="relative border-l-2 border-slate-150 pl-6 space-y-6 ml-3">
                {selectedProperty.timeline.map((event, idx) => (
                  <div key={event.id || idx} className="relative">
                    {/* Circle Node */}
                    <span className={`absolute -left-[31px] top-1.5 flex h-4 w-4 rounded-full border-2 border-white ${
                      event.type === "visit" 
                        ? "bg-emerald-500" 
                        : event.type === "repair" 
                        ? "bg-purple-500" 
                        : event.type === "creation" 
                        ? "bg-slate-400" 
                        : "bg-indigo-400"
                    }`} />
                    
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-medium text-slate-400">{event.date}</span>
                        <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 px-1 hover:bg-slate-100 rounded leading-none">
                          {event.type}
                        </span>
                      </div>
                      <h5 className="text-xs font-bold text-slate-800">{event.title}</h5>
                      <p className="text-xs text-slate-600 font-sans leading-relaxed">{event.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Active Findings */}
          {drawerTab === "findings" && (
            <div className="space-y-6 animate-fade-in">
              <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
                <AlertTriangle className="h-4.5 w-4.5 text-slate-500" />
                <span>Found Hazards & Technical Recommendations</span>
              </h4>

              <div className="grid grid-cols-1 gap-4">
                {selectedProperty.openIssues.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl">
                    <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto mb-1.5" />
                    <p className="text-xs font-semibold text-slate-700">No active findings logged.</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">Technicians can log issues during scheduled field visits.</p>
                  </div>
                ) : (
                  selectedProperty.openIssues.map(issue => (
                    <div key={issue.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className={`text-[9px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full ${
                          issue.severity === "high" 
                            ? "bg-red-500 text-white" 
                            : issue.severity === "medium" 
                            ? "bg-orange-100 text-orange-850" 
                            : "bg-blue-100 text-blue-800"
                        }`}>
                          {issue.severity} priority
                        </span>
                        
                        <button
                          id={`toggle-issue-btn-${issue.id}`}
                          onClick={() => onToggleIssue(selectedProperty.id, issue.id)}
                          className={`text-xs font-bold py-1 px-2.5 rounded-lg border transition ${
                            issue.resolved 
                              ? "bg-slate-200 text-slate-600 border-slate-200" 
                              : "bg-white text-emerald-700 hover:bg-emerald-50 border-emerald-200"
                          }`}
                        >
                          {issue.resolved ? "Reopen Finding" : "Mark Resolved"}
                        </button>
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-slate-900 font-mono text-slate-500 uppercase">{issue.category}</h4>
                        <p className="text-xs text-slate-700 font-sans leading-relaxed">{issue.description}</p>
                      </div>

                      <div className="p-2.5 bg-yellow-50 border border-yellow-100 rounded-lg text-slate-700">
                        <span className="block text-[9px] font-bold text-yellow-800 uppercase tracking-wider mb-0.5 leading-none">
                          Technician Recommended Action:
                        </span>
                        <p className="text-xs font-sans mt-0.5 font-medium">{issue.recommendedAction}</p>
                      </div>

                      {!issue.resolved && (
                        <div className="flex items-center justify-end border-t border-slate-200/50 pt-2 shrink-0">
                          <button
                            id={`drawer-issue-convert-est-${issue.id}`}
                            onClick={() => onBuildEstimateFromIssue(selectedProperty.id, issue)}
                            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                          >
                            <span>Generate Corrective Plan Estimate</span>
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Tab 4: Vault & Manuals */}
          {drawerTab === "vault" && (
            <div className="space-y-6 animate-fade-in">
              <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
                <FolderLock className="h-4.5 w-4.5 text-slate-500" />
                <span>Property Document Vault</span>
              </h4>

              <div className="grid grid-cols-1 gap-3">
                {selectedProperty.vault.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 bg-slate-50/50 border border-slate-200 rounded-lg">
                    <p className="text-xs font-medium">No files or manuals archived yet.</p>
                  </div>
                ) : (
                  selectedProperty.vault.map(item => (
                    <div key={item.id} className="p-4 bg-slate-50 border border-slate-150 rounded-lg hover:bg-slate-100 transition flex items-start gap-3">
                      <div className="p-2 rounded bg-indigo-100 text-indigo-700 shrink-0">
                        <FileText className="h-4 w-4" />
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <h5 className="text-xs font-bold text-slate-800">{item.title}</h5>
                          <span className="text-[10px] font-mono text-slate-400">Added {item.dateAdded}</span>
                        </div>
                        <span className="inline-block text-[9px] font-bold uppercase text-indigo-500 font-mono">{item.category}</span>
                        <p className="text-xs text-slate-600 font-sans leading-relaxed mt-1">{item.description}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Upload Vault Form */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                <h5 className="text-xs font-bold text-slate-800 uppercase tracking-widest border-b border-slate-200 pb-2 flex items-center gap-1">
                  <Lock className="h-4 w-4 text-indigo-600" /> Archive System Manual or Paint Code
                </h5>
                <form onSubmit={(e) => handleAddVaultSubmit(e, selectedProperty.id)} className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                      Manual Title
                    </label>
                    <input
                      id="vault-form-title"
                      type="text"
                      placeholder="e.g. SW Alabaster SW7008 Paint formula"
                      value={newVaultTitle}
                      onChange={(e) => setNewVaultTitle(e.target.value)}
                      className="w-full text-xs border border-slate-200 bg-white rounded-md p-2 focus:outline-emerald-500"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 pb-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                        Category
                      </label>
                      <select
                        id="vault-form-category"
                        value={newVaultCategory}
                        onChange={(e) => setNewVaultCategory(e.target.value)}
                        className="w-full text-xs border border-slate-200 bg-white p-2 rounded-md focus:outline-emerald-500"
                      >
                        <option value="HVAC / Mechanical">HVAC / Mechanical</option>
                        <option value="Plumbing / Flow">Plumbing / Flow</option>
                        <option value="Structural / Exterior">Structural / Exterior</option>
                        <option value="Paint / Finishes">Paint / Finishes</option>
                      </select>
                    </div>
                    <div className="p-0.5 flex flex-col justify-end shrink-0">
                      <div className="p-2 border border-slate-200 border-dashed rounded text-[10px] text-center bg-white text-slate-400 font-mono font-medium leading-none">
                        Drag-and-Drop Supported
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 text-slate-600">
                      Description or Model Specs
                    </label>
                    <textarea
                      id="vault-form-desc"
                      rows={2}
                      placeholder="Add important installation dates, serial bounds, filter numbers, or color formula ratios..."
                      value={newVaultDesc}
                      onChange={(e) => setNewVaultDesc(e.target.value)}
                      className="w-full text-xs border border-slate-200 bg-white rounded-md p-2 focus:outline-emerald-500 resize-none"
                    />
                  </div>

                  <button
                    id="vault-form-submit-btn"
                    type="submit"
                    className="w-full py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-xs font-bold transition flex items-center justify-center gap-1.5"
                  >
                    Archive Document Item
                  </button>
                </form>
              </div>

            </div>
          )}

        </Drawer>
      )}

    </div>
  );
}
