import React, { useState } from "react";
import { 
  ClipboardCheck, 
  Plus, 
  Trash2, 
  Play, 
  DollarSign, 
  User, 
  MapPin, 
  ArrowRight,
  TrendingUp,
  Files
} from "lucide-react";
import { DatabaseState, Estimate, EstimateItem } from "../types";

interface AdminEstimatesProps {
  db: DatabaseState;
  onAddEstimate: (estimate: Estimate) => void;
  onApproveEstimate: (id: string) => void;
}

export default function AdminEstimates({
  db,
  onAddEstimate,
  onApproveEstimate
}: AdminEstimatesProps) {
  const [selectedClientId, setSelectedClientId] = useState(db.clients[0]?.id || "");
  const [selectedPropertyId, setSelectedPropertyId] = useState("");
  const [estimateTitle, setEstimateTitle] = useState("Preventive Home Care Assessment");
  const [notes, setNotes] = useState("");

  // Line items state
  const [lineItems, setLineItems] = useState<EstimateItem[]>([
    { name: "Standard Handyman Initial Visit", description: "Audit of HVAC mechanicals and initial diagnostic check.", price: 150, quantity: 1 }
  ]);

  // For adding products from PriceBook template
  const [selectedPriceBookId, setSelectedPriceBookId] = useState(db.priceBook[0]?.id || "");

  // Align selected property automatically when client changes
  React.useEffect(() => {
    const clientProperties = db.properties.filter(p => p.clientId === selectedClientId);
    if (clientProperties.length > 0) {
      setSelectedPropertyId(clientProperties[0].id);
    } else {
      setSelectedPropertyId("");
    }
  }, [selectedClientId, db.properties]);

  const handleAddPriceBookLine = () => {
    const template = db.priceBook.find(pb => pb.id === selectedPriceBookId);
    if (!template) return;

    // Check if duplicate line
    const exists = lineItems.find(item => item.name === template.name);
    if (exists) {
      setLineItems(lineItems.map(item => 
        item.name === template.name ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setLineItems([...lineItems, {
        name: template.name,
        description: template.customerDescription.substring(0, 80) + "...",
        price: template.minimumPrice,
        quantity: 1
      }]);
    }
  };

  const handleRemoveLine = (index: number) => {
    setLineItems(lineItems.filter((_, idx) => idx !== index));
  };

  const handleSaveDraft = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClientId || !selectedPropertyId || lineItems.length === 0) return;

    const total = lineItems.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
    const newEst: Estimate = {
      id: `est-${Date.now()}`,
      clientId: selectedClientId,
      propertyId: selectedPropertyId,
      title: estimateTitle || "Custom Maintenance Estimate",
      items: [...lineItems],
      total,
      status: "sent", // Send straight to homeowner portal for review
      createdAt: new Date().toISOString(),
      notes: notes || "Standard preventative maintenance recommendation."
    };

    onAddEstimate(newEst);
    
    // Reset lines
    setEstimateTitle("Preventive Home Care Assessment");
    setNotes("");
    setLineItems([
      { name: "Standard Handyman Initial Visit", description: "Audit of HVAC mechanicals and initial diagnostic.", price: 150, quantity: 1 }
    ]);
  };

  return (
    <div className="space-y-8 animate-fade-in" id="admin-estimates-view">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Estimates & Quote Builder</h2>
        <p className="text-sm text-slate-500 mt-1 font-sans">
          Construct professional quotes directly from Price Book templates. Approved quotes automatically trigger visits and invoices.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Hand: Estimate Creation Form */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl shadow-xs p-6 space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
            <ClipboardCheck className="h-5 w-5 text-emerald-600" />
            <h3 className="font-semibold text-slate-900">Configure Scope of Work</h3>
          </div>

          <form onSubmit={handleSaveDraft} className="space-y-6 font-sans">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Target Customer
                </label>
                <select
                  id="est-form-client"
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full text-sm border border-slate-200 bg-slate-50 p-2.5 rounded-lg focus:outline-emerald-500"
                >
                  {db.clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name} ({c.email})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Home Property record
                </label>
                <select
                  id="est-form-property"
                  value={selectedPropertyId}
                  onChange={(e) => setSelectedPropertyId(e.target.value)}
                  className="w-full text-sm border border-slate-200 bg-slate-50 p-2.5 rounded-lg focus:outline-emerald-500"
                >
                  {db.properties
                    .filter(p => p.clientId === selectedClientId)
                    .map(p => (
                      <option key={p.id} value={p.id}>{p.address.split(",")[0]}</option>
                    ))
                  }
                  {db.properties.filter(p => p.clientId === selectedClientId).length === 0 && (
                    <option value="">No Property Records Registered</option>
                  )}
                </select>
              </div>

            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Estimate Action Title
              </label>
              <input
                id="est-form-title"
                type="text"
                placeholder="e.g. Crawlspace Repair & Fan Flush Care"
                value={estimateTitle}
                onChange={(e) => setEstimateTitle(e.target.value)}
                className="w-full text-sm border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-emerald-500 transition"
                required
              />
            </div>

            {/* Selection from price book */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">
                Add Line Item from price book
              </span>
              <div className="flex gap-3">
                <select
                  id="est-form-pb-select"
                  value={selectedPriceBookId}
                  onChange={(e) => setSelectedPriceBookId(e.target.value)}
                  className="flex-1 text-xs border border-slate-200 bg-white p-2 rounded-lg focus:outline-emerald-500"
                >
                  {db.priceBook.map(pb => (
                    <option key={pb.id} value={pb.id}>{pb.name} (${pb.minimumPrice})</option>
                  ))}
                </select>
                <button
                  id="est-form-add-pb-line-btn"
                  type="button"
                  onClick={handleAddPriceBookLine}
                  className="py-2 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition flex items-center gap-1 shrink-0"
                >
                  <Plus className="h-4 w-4" /> Add Item
                </button>
              </div>
            </div>

            {/* Line items table */}
            <div className="space-y-3 shrink-0">
              <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider leading-none">
                Active estimate line items
              </span>
              <div className="border border-slate-150 rounded-xl overflow-hidden divide-y divide-slate-150">
                {lineItems.map((item, idx) => (
                  <div key={idx} className="p-4 bg-white flex items-center justify-between gap-4">
                    <div className="flex-1 space-y-0.5 min-w-0 pr-4">
                      <h4 className="text-xs font-bold text-slate-900 truncate">{item.name}</h4>
                      <p className="text-[11px] text-slate-400 font-sans truncate">{item.description}</p>
                    </div>
                    <div className="flex items-center gap-4 shrink-0">
                      <div className="flex items-center gap-1 text-xs text-slate-600 font-medium">
                        <span>Qty:</span>
                        <input
                          id={`est-form-line-qty-${idx}`}
                          type="number"
                          value={item.quantity}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 1;
                            setLineItems(lineItems.map((li, i) => i === idx ? { ...li, quantity: val } : li));
                          }}
                          className="w-10 text-center border border-slate-200 bg-slate-50 select-all p-1 rounded font-mono text-xs font-bold text-slate-950"
                          min="1"
                        />
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-900 whitespace-nowrap">
                        ${item.price * item.quantity}
                      </span>
                      <button
                        id={`est-form-remove-line-${idx}`}
                        type="button"
                        onClick={() => handleRemoveLine(idx)}
                        className="text-slate-400 hover:text-red-500 p-1 transition shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Note text and total indicator */}
            <div className="flex flex-col md:flex-row md:items-start gap-4 justify-between border-t border-slate-150 pt-4">
              <div className="flex-1">
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Lead Generation Advisor Notes
                </label>
                 <textarea
                  id="est-form-notes"
                  rows={2}
                  placeholder="Notes shown to the client on portal checkout..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs border border-slate-200 bg-slate-50 focus:bg-white rounded-lg p-2.5 focus:outline-emerald-500 resize-none transition"
                />
              </div>

              <div className="p-4 bg-slate-900 text-white rounded-xl text-right md:w-56 shrink-0">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Estimated Total</span>
                <span className="block text-2xl font-mono font-bold text-emerald-400 mt-1">
                  ${lineItems.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0).toLocaleString()}
                </span>
                <span className="text-[9px] text-slate-400">Net price includes local Markups</span>
              </div>
            </div>

            <button
              id="est-form-submit-btn"
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-900 font-bold tracking-tight text-sm text-center transition shadow-xs"
            >
              Publish & Send Estimate to Client Portal
            </button>
          </form>
        </div>

        {/* Right Hand: Active Estimates Pipeline List */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <h3 className="font-semibold text-slate-900">Estimates History</h3>
            <span className="text-xs font-mono font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
              {db.estimates.length} bids
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {db.estimates.length === 0 ? (
              <div className="p-12 text-center text-slate-400 text-sm">
                No active estimates found on file.
              </div>
            ) : (
              db.estimates.map(est => {
                const client = db.clients.find(c => c.id === est.clientId);
                const property = db.properties.find(p => p.id === est.propertyId);

                return (
                  <div key={est.id} className="p-5 space-y-3 hover:bg-slate-50/50 transition">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono leading-none bg-slate-150 px-1.5 py-0.5 rounded text-slate-500 font-bold">
                        #{est.id}
                      </span>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        est.status === "approved" 
                          ? "bg-emerald-50 text-emerald-700 border border-emerald-200" 
                          : est.status === "declined" 
                          ? "bg-slate-100 text-slate-500" 
                          : "bg-blue-50 text-blue-700 border border-blue-200"
                      }`}>
                        {est.status}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-slate-950 font-sans leading-tight">{est.title}</h4>
                      <p className="text-xs text-slate-500 font-sans">
                        Client: <span className="font-semibold text-slate-700">{client ? client.name : "N/A"}</span>
                      </p>
                      <p className="text-[11px] text-slate-400 font-sans flex items-start gap-1">
                        <MapPin className="h-3 w-3 shrink-0 mt-0.5 text-slate-400" />
                        <span>{property ? property.address.split(",")[0] : ""}</span>
                      </p>
                    </div>

                    {/* Short list of items in estimate config */}
                    <div className="text-[10px] text-slate-500 pl-4 border-l-2 border-slate-150 space-y-0.5 shrink-0">
                      {est.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between font-sans">
                          <span className="truncate max-w-[140px]">{item.name}</span>
                          <span className="font-mono">{item.quantity}x • ${item.price}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 shrink-0">
                      <span className="text-sm font-bold text-slate-900 font-mono">${est.total}</span>
                      
                      {est.status === "sent" && (
                        <button
                          id={`estimates-quick-approve-${est.id}`}
                          onClick={() => onApproveEstimate(est.id)}
                          className="py-1 px-2.5 rounded bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-[11px] font-bold transition flex items-center gap-1 shadow-xs"
                        >
                          <Play className="h-3.5 w-3.5" />
                          <span>Dispatch job</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
