import React from "react";
import { 
  ClipboardCopy, 
  Wrench, 
  DollarSign, 
  AlertTriangle, 
  CheckCircle, 
  CalendarDays, 
  Check, 
  ArrowRight,
  TrendingUp,
  Flame,
  UserCheck
} from "lucide-react";
import { DatabaseState, Visit, Estimate, OpenIssue, Invoice } from "../types";

interface AdminMyDayProps {
  db: DatabaseState;
  onApproveEstimate: (estId: string) => void;
  onRecordPayment: (invId: string) => void;
  onBuildEstimateFromIssue: (propertyId: string, issue: OpenIssue) => void;
  onSelectTab: (tab: string) => void;
}

export default function AdminMyDay({
  db,
  onApproveEstimate,
  onRecordPayment,
  onBuildEstimateFromIssue,
  onSelectTab
}: AdminMyDayProps) {
  const todayStr = "2026-05-24"; // System static date

  // Calculations
  const pendingIntakes = db.intakes.filter(i => i.status === "pending");
  const reviewsCount = db.estimates.filter(e => e.status === "draft" || e.status === "sent");
  const todayVisits = db.visits.filter(v => v.date === todayStr);
  const unpaidInvs = db.invoices.filter(i => i.status === "unpaid");
  
  // Find properties with high-severity open issues
  const propertiesWithAlerts = db.properties.filter(p => p.openIssues.some(i => !i.resolved));
  const activeMemberships = db.memberships.filter(m => m.status === "active");

  return (
    <div className="space-y-8 animate-fade-in" id="admin-myday-view">
      {/* Page Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Owner Command Center</h2>
        <p className="text-sm text-slate-500 mt-1 font-sans">
          Welcome back. Here is the operational brain and daily focus for Dovetails Services on <span className="font-semibold text-slate-700">Sunday, May 24, 2026</span>.
        </p>
      </div>

      {/* KPI Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
        
        {/* Card 1: Intake Requests */}
        <div 
          onClick={() => onSelectTab("intake")}
          className="flex flex-col justify-between p-5 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-400 hover:shadow-xs transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Booking Intake</span>
            <div className="p-2 rounded-lg bg-orange-100 text-orange-600 transition group-hover:scale-105">
              <Flame className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-slate-900 font-mono tracking-tight">
              {pendingIntakes.length}
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans flex items-center gap-1">
              <span>Awaiting review</span>
              <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </p>
          </div>
        </div>

        {/* Card 2: Estimates */}
        <div 
          onClick={() => onSelectTab("estimates")}
          className="flex flex-col justify-between p-5 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-400 hover:shadow-xs transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Open Estimates</span>
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 transition group-hover:scale-105">
              <ClipboardCopy className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-slate-900 font-mono tracking-tight">
              {reviewsCount.length}
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              ${reviewsCount.reduce((acc, current) => acc + current.total, 0).toLocaleString()} pipeline value
            </p>
          </div>
        </div>

        {/* Card 3: Today's visits */}
        <div 
          onClick={() => onSelectTab("properties")}
          className="flex flex-col justify-between p-5 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-400 hover:shadow-xs transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Scheduled Today</span>
            <div className="p-2 rounded-lg bg-indigo-100 text-indigo-700 transition group-hover:scale-105">
              <Wrench className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-slate-900 font-mono tracking-tight">
              {todayVisits.length}
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              {todayVisits.filter(v => v.status === "completed").length} of {todayVisits.length} finished
            </p>
          </div>
        </div>

        {/* Card 4: Unpaid Invoices */}
        <div 
          onClick={() => onSelectTab("invoices")}
          className="flex flex-col justify-between p-5 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-400 hover:shadow-xs transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Unpaid Billing</span>
            <div className="p-2 rounded-lg bg-red-100 text-red-600 transition group-hover:scale-105">
              <DollarSign className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-slate-900 font-mono tracking-tight">
              {unpaidInvs.length}
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans text-red-500 font-medium">
              ${unpaidInvs.reduce((acc, val) => acc + val.total, 0).toLocaleString()} outstanding
            </p>
          </div>
        </div>

        {/* Card 5: Memberships */}
        <div 
          onClick={() => onSelectTab("memberships")}
          className="flex flex-col justify-between p-5 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-400 hover:shadow-xs transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider font-sans">Memberships</span>
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 transition group-hover:scale-105">
              <UserCheck className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-slate-900 font-mono tracking-tight">
              {activeMemberships.length}
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              ${activeMemberships.length * 49}/mo recurring MRR
            </p>
          </div>
        </div>

      </div>

      {/* Main Attention Board Split Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left Column: Scheduled Visits & Estimates Pending Review */}
        <div className="space-y-8">
          
          {/* Section 1: Today's Service Visits */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-slate-600" />
                <h3 className="font-semibold text-slate-900">Today's Visits Routing</h3>
              </div>
              <span className="text-xs font-mono font-bold bg-slate-200 px-2 py-0.5 rounded text-slate-700 uppercase">
                {todayStr}
              </span>
            </div>
            
            <div className="divide-y divide-slate-100">
              {todayVisits.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">
                  No visits scheduled for today. Create new schedule options.
                </div>
              ) : (
                todayVisits.map(visit => {
                  const client = db.clients.find(c => c.id === visit.clientId);
                  const property = db.properties.find(p => p.id === visit.propertyId);
                  
                  return (
                    <div key={visit.id} className="p-5 flex items-start justify-between hover:bg-slate-50/50 transition">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded uppercase">
                            {visit.timeSlot}
                          </span>
                          <span className="text-xs font-mono font-medium text-slate-500">
                            Mechanic: <span className="font-semibold text-slate-700">{visit.techName}</span>
                          </span>
                        </div>
                        <h4 className="text-sm font-semibold text-slate-900 mt-2">
                          {client ? client.name : "Unknown Client"}
                        </h4>
                        <p className="text-xs text-slate-400">
                          {property ? property.address : "No Address Listed"}
                        </p>
                      </div>

                      <div className="flex flex-col items-end gap-2 shrink-0">
                        {visit.status === "completed" ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-700 border border-emerald-200">
                            <CheckCircle className="h-3.5 w-3.5" /> Checked Out
                          </span>
                        ) : visit.status === "arrived" ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-indigo-50 px-2 py-1 text-xs font-semibold text-indigo-700 border border-indigo-200 animate-pulse">
                            ● In Progress
                          </span>
                        ) : visit.status === "on_way" ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-1 text-xs font-semibold text-amber-700 border border-amber-200">
                            ⚡ On My Way
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-slate-50 px-2 py-1 text-xs font-semibold text-slate-500 border border-slate-200">
                            Dispatched
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 font-mono">
                          {visit.checklist.filter(c => c.completed).length} / {visit.checklist.length} tasks clear
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Section 2: Estimates Pending Review */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <ClipboardCopy className="h-5 w-5 text-slate-600" />
                <h3 className="font-semibold text-slate-900">Estimates Pipeline Review</h3>
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                Action Required
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {reviewsCount.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">
                  Prisinte pipeline. No draft or sent estimates waiting review.
                </div>
              ) : (
                reviewsCount.map(est => {
                  const client = db.clients.find(c => c.id === est.clientId);
                  const property = db.properties.find(p => p.id === est.propertyId);
                  
                  return (
                    <div key={est.id} className="p-5 flex items-center justify-between hover:bg-slate-50/50 transition">
                      <div className="space-y-1 pr-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-slate-400">#{est.id}</span>
                          <span className={`text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded ${
                            est.status === "sent" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
                          }`}>
                            {est.status}
                          </span>
                        </div>
                        <h4 className="text-sm font-semibold text-slate-900 line-clamp-1">{est.title}</h4>
                        <p className="text-xs text-slate-500 font-sans">
                          {client ? client.name : "Prospect"} • {property ? property.address.split(",")[0] : ""}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-sm font-bold text-slate-900 font-mono">${est.total}</span>
                        <button
                          id={`approve-est-btn-${est.id}`}
                          onClick={() => onApproveEstimate(est.id)}
                          className="inline-flex items-center justify-center p-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-900 font-bold transition"
                          title="Authorize and dispatch job"
                        >
                          <Check className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>

        {/* Right Column: High Risk Issues & Unpaid Billing */}
        <div className="space-y-8">
          
          {/* Section 3: Open Home Findings & Preventative Leads */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-slate-600" />
                <h3 className="font-semibold text-slate-900">Home Health Safety Risks</h3>
              </div>
              <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded">
                Predictive Action
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {propertiesWithAlerts.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">
                  Perfect home safety record. All technician findings resolved.
                </div>
              ) : (
                propertiesWithAlerts.map(prop => {
                  const client = db.clients.find(c => c.id === prop.clientId);
                  const activeIssues = prop.openIssues.filter(i => !i.resolved);

                  if (activeIssues.length === 0) return null;

                  return (
                    <div key={prop.id} className="p-5 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-widest font-mono">
                            Home: {prop.address.split(",")[0]}
                          </h4>
                          <span className="text-xs font-medium text-slate-700">
                            Owner: {client ? client.name : "None"}
                          </span>
                        </div>
                        <span className="text-xs font-mono bg-red-100 text-red-800 px-2 py-0.5 rounded font-semibold">
                          {activeIssues.length} open issues
                        </span>
                      </div>

                      {/* Issue stack */}
                      <div className="space-y-2.5">
                        {activeIssues.map(issue => (
                          <div key={issue.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-slate-200 transition">
                            <div className="flex items-center gap-2 mb-1">
                              <span className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                                issue.severity === "high" 
                                  ? "bg-red-500 text-white" 
                                  : issue.severity === "medium" 
                                  ? "bg-orange-100 text-orange-900" 
                                  : "bg-blue-100 text-blue-900"
                              }`}>
                                {issue.severity} Priority
                              </span>
                              <span className="text-[10px] font-mono font-medium text-slate-400 uppercase">
                                {issue.category}
                              </span>
                            </div>
                            <p className="text-xs text-slate-700 font-sans leading-relaxed">{issue.description}</p>
                            
                            {/* Action triggering */}
                            <div className="mt-2.5 flex items-center justify-between border-t border-slate-200/60 pt-2 shrink-0">
                              <span className="text-[10px] text-slate-400 italic font-medium leading-none">
                                Rec: {issue.recommendedAction.substring(0, 40)}...
                              </span>
                              <button
                                id={`action-issue-est-${issue.id}`}
                                onClick={() => onBuildEstimateFromIssue(prop.id, issue)}
                                className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 shrink-0"
                              >
                                <span>Create Estimate</span>
                                <ArrowRight className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Section 4: Outstanding Invoices / Accounts Receivable */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-slate-600" />
                <h3 className="font-semibold text-slate-900">Accounts Receivable</h3>
              </div>
              <span className="text-xs font-mono font-bold text-red-600">
                Overdue Check
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {unpaidInvs.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">
                  Perfect billing. No outstanding unpaid customer accounts.
                </div>
              ) : (
                unpaidInvs.map(inv => {
                  const client = db.clients.find(c => c.id === inv.clientId);
                  
                  return (
                    <div key={inv.id} className="p-5 flex items-center justify-between hover:bg-slate-50/50 transition">
                      <div className="space-y-0.5 pr-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-slate-400">#{inv.id}</span>
                          <span className="text-xs text-slate-400 font-sans">
                            Due {inv.dueDate}
                          </span>
                        </div>
                        <h4 className="text-sm font-semibold text-slate-900">
                          {client ? client.name : "General Customer"}
                        </h4>
                        <p className="text-xs text-slate-500 leading-none">{inv.title}</p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-sm font-bold text-red-600 font-mono">${inv.total}</span>
                        <button
                          id={`record-payment-btn-${inv.id}`}
                          onClick={() => onRecordPayment(inv.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-xs font-bold transition"
                        >
                          Paid
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
