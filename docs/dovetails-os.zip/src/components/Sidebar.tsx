import React from "react";
import { 
  Shield, 
  User, 
  Wrench, 
  CalendarDays, 
  ClipboardCheck, 
  Users, 
  DollarSign, 
  BookOpen, 
  HeartHandshake, 
  Activity,
  Layers,
  ChevronRight,
  MessageSquare
} from "lucide-react";
import { UserRole } from "../types";

interface SidebarProps {
  currentRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  unpaidCount: number;
  pendingIntakes: number;
  pendingEstimates: number;
}

export default function Sidebar({
  currentRole,
  onChangeRole,
  activeTab,
  onSelectTab,
  unpaidCount,
  pendingIntakes,
  pendingEstimates
}: SidebarProps) {
  // Navigation elements by Role
  const adminNav = [
    { id: "myday", label: "My Day", icon: CalendarDays, badge: null },
    { id: "intake", label: "Intake Pool", icon: Layers, badge: pendingIntakes > 0 ? pendingIntakes : null },
    { id: "properties", label: "Properties & Clients", icon: Users, badge: null },
    { id: "estimates", label: "Estimates", icon: ClipboardCheck, badge: pendingEstimates > 0 ? pendingEstimates : null },
    { id: "pricebook", label: "Price Book", icon: BookOpen, badge: null },
    { id: "memberships", label: "Memberships", icon: HeartHandshake, badge: null },
    { id: "invoices", label: "Invoices", icon: DollarSign, badge: unpaidCount > 0 ? unpaidCount : null },
    { id: "logs", label: "Audit & Logs", icon: Activity, badge: null }
  ];

  return (
    <div className="flex h-full w-64 flex-col bg-slate-900 text-slate-100 border-r border-slate-800 shrink-0">
      {/* Brand Header */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-800 bg-slate-950">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500 text-slate-900 font-bold text-xl">
          D
        </div>
        <div>
          <h1 className="text-md font-bold tracking-tight text-white leading-none">Dovetails OS</h1>
          <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-semibold">Home Intel Engine</span>
        </div>
      </div>

      {/* Role Selection Picker */}
      <div className="px-4 py-4 border-b border-slate-800 bg-slate-900/50">
        <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
          Simulator Role View
        </label>
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded-lg">
          <button
            id="role-btn-admin"
            onClick={() => onChangeRole(UserRole.ADMIN)}
            className={`flex flex-col items-center justify-center py-2 px-1 rounded-md text-center transition ${
              currentRole === UserRole.ADMIN
                ? "bg-emerald-500 text-slate-900 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <Shield className="h-4 w-4 mb-0.5" />
            <span className="text-[9px] font-medium leading-none">Admin</span>
          </button>
          <button
            id="role-btn-tech"
            onClick={() => onChangeRole(UserRole.TECHNICIAN)}
            className={`flex flex-col items-center justify-center py-2 px-1 rounded-md text-center transition ${
              currentRole === UserRole.TECHNICIAN
                ? "bg-emerald-500 text-slate-900 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <Wrench className="h-4 w-4 mb-0.5" />
            <span className="text-[9px] font-medium leading-none">Tech</span>
          </button>
          <button
            id="role-btn-client"
            onClick={() => onChangeRole(UserRole.CLIENT)}
            className={`flex flex-col items-center justify-center py-2 px-1 rounded-md text-center transition ${
              currentRole === UserRole.CLIENT
                ? "bg-emerald-500 text-slate-900 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <User className="h-4 w-4 mb-0.5" />
            <span className="text-[9px] font-medium leading-none">Client</span>
          </button>
        </div>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {currentRole === UserRole.ADMIN && (
          <>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-widest text-slate-500">
              Operations Control
            </div>
            {adminNav.map(item => {
              const IconComp = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  id={`nav-tab-${item.id}`}
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`flex w-full items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium tracking-tight transition group ${
                    isActive
                      ? "bg-slate-800 text-white border-l-4 border-emerald-500 pl-2"
                      : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/40"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <IconComp className={`h-4.5 w-4.5 shrink-0 ${isActive ? "text-emerald-400" : "text-slate-500 group-hover:text-slate-300"}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== null && (
                    <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-emerald-500/20 px-1.5 text-[10px] font-bold text-emerald-400 font-mono">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </>
        )}

        {currentRole === UserRole.TECHNICIAN && (
          <>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-widest text-slate-500">
              Technician View
            </div>
            <button
              id="nav-tab-tech-today"
              onClick={() => onSelectTab("tech-today")}
              className={`flex w-full items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === "tech-today"
                  ? "bg-slate-800 text-white border-l-4 border-emerald-500 pl-2"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/40"
              }`}
            >
              <Wrench className="h-4.5 w-4.5 text-emerald-400" />
              <span>Today's Route</span>
            </button>
          </>
        )}

        {currentRole === UserRole.CLIENT && (
          <>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-widest text-slate-500">
              Homeowner Portal
            </div>
            <button
              id="nav-tab-client-portal"
              onClick={() => onSelectTab("client-portal")}
              className={`flex w-full items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === "client-portal"
                  ? "bg-slate-800 text-white border-l-4 border-emerald-500 pl-2"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/40"
              }`}
            >
              <User className="h-4.5 w-4.5 text-emerald-400" />
              <span>Home Hub & AI Advisor</span>
            </button>
          </>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-4 border-t border-slate-800 bg-slate-950 text-slate-500 text-[10px] font-mono flex flex-col gap-1">
        <div>Dovetails Services LLC</div>
        <div className="flex items-center gap-1.5 text-slate-400">
          <span className="inline-block h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>SYSTEM ONLINE</span>
        </div>
      </div>
    </div>
  );
}
