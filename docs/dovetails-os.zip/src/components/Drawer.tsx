import React from "react";
import { AnimatePresence, motion } from "motion/react";
import { X } from "lucide-react";

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  contextLine?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

export default function Drawer({
  isOpen,
  onClose,
  title,
  contextLine,
  children,
  footer
}: DrawerProps) {
  // Confirm prompt for unsaved changes can be handled at component level or triggers onClose
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop Overlay */}
          <motion.div
            id="drawer-overlay"
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Drawer Body Panel */}
          <motion.div
            id="drawer-panel"
            className="relative z-10 flex h-full w-full max-w-xl flex-col bg-white shadow-2xl border-l border-slate-200"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 p-6 bg-slate-50">
              <div>
                <h3 className="text-lg font-semibold text-slate-900 leading-tight">
                  {title}
                </h3>
                {contextLine && (
                  <p className="mt-1 text-xs font-mono text-slate-500">
                    {contextLine}
                  </p>
                )}
              </div>
              <button
                id="drawer-close-btn"
                onClick={onClose}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content Section */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
              {children}
            </div>

            {/* Persistent Action Footer */}
            {footer && (
              <div className="border-t border-slate-100 bg-slate-50 p-6 flex items-center justify-end gap-3 shrink-0">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
