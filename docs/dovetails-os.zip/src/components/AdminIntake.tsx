import React, { useState } from "react";
import { 
  PlusCircle, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  CheckCircle, 
  UserCheck, 
  ExternalLink,
  Bot
} from "lucide-react";
import { DatabaseState, Intake } from "../types";

interface AdminIntakeProps {
  db: DatabaseState;
  onCreateIntake: (intakeData: Omit<Intake, "id" | "status" | "createdAt">) => void;
  onConvertIntake: (id: string) => void;
}

export default function AdminIntake({
  db,
  onCreateIntake,
  onConvertIntake
}: AdminIntakeProps) {
  // Local form state
  const [customerName, setCustomerName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [source, setSource] = useState("Web Form");
  const [preferredDate, setPreferredDate] = useState("");
  const [notes, setNotes] = useState("");
  const [errorText, setErrorText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText("");

    if (!customerName.trim() || !address.trim() || !notes.trim()) {
      setErrorText("Required fields must be explicitly populated. Name, Address, and Inquiry details are mandatory.");
      return;
    }

    onCreateIntake({
      customerName,
      email,
      phone,
      address,
      source,
      preferredDate: preferredDate || new Date().toISOString().split("T")[0],
      notes
    });

    // Reset
    setCustomerName("");
    setEmail("");
    setPhone("");
    setAddress("");
    setPreferredDate("");
    setNotes("");
  };

  return (
    <div className="space-y-8 animate-fade-in" id="admin-intake-view">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Onboarding & Intake Pool</h2>
        <p className="text-sm text-slate-500 mt-1 font-sans">
          Log phone requests, evaluate online booking forms, and authorize homeowner preventative maintenance setups.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        
        {/* Left Hand: Capture Interactive Booking Request Form */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-6 h-fit space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
            <PlusCircle className="h-5 w-5 text-emerald-600" />
            <h3 className="font-semibold text-slate-900">Direct Intake Logger</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {errorText && (
              <p className="text-xs font-semibold text-rose-500 bg-rose-50 p-2.5 rounded border border-rose-100 leading-snug">
                {errorText}
              </p>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Customer Name <span className="text-rose-500">*</span>
              </label>
              <input
                id="intake-form-name"
                type="text"
                placeholder="e.g. David Miller"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Email Address
                </label>
                <input
                  id="intake-form-email"
                  type="email"
                  placeholder="name@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Phone Number
                </label>
                <input
                  id="intake-form-phone"
                  type="text"
                  placeholder="(603) 555-xxxx"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Property Address <span className="text-rose-500">*</span>
              </label>
              <input
                id="intake-form-address"
                type="text"
                placeholder="e.g., 102 High St, Manchester, NH"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Preferred Date
                </label>
                <input
                  id="intake-form-date"
                  type="date"
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                  Inquiry Source
                </label>
                <select
                  id="intake-form-source"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition"
                >
                  <option value="Web Booking Form">Web Booking Form</option>
                  <option value="Phone Call">Phone Call</option>
                  <option value="Google Local Services">Google Local Services</option>
                  <option value="Referral Plan">Referral Plan</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                Preventative Request & Problem Details <span className="text-rose-500">*</span>
              </label>
              <textarea
                id="intake-form-notes"
                rows={3}
                placeholder="Describe what needs fixing or auditing..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-emerald-500 transition resize-none"
              />
            </div>

            <button
              id="intake-form-submit-btn"
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-900 font-bold tracking-tight text-sm transition shadow-xs"
            >
              Log Intake Record
            </button>
          </form>
        </div>

        {/* Right Hand: Active & Historic Intake Tickets List */}
        <div className="xl:col-span-2 bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <h3 className="font-semibold text-slate-900">Incoming Requests & Leads Pool</h3>
            <span className="text-xs font-mono font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
              {db.intakes.length} total tickets
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {db.intakes.length === 0 ? (
              <div className="p-16 text-center text-slate-400">
                <Bot className="h-10 w-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-medium">No booking intakes recorded yet.</p>
                <p className="text-xs text-slate-400 mt-1">Use the logging tool on the left to capture raw customer details.</p>
              </div>
            ) : (
              db.intakes.map(ticket => (
                <div key={ticket.id} className="p-6 space-y-4 hover:bg-slate-50/50 transition">
                  {/* Status row */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-400">#{ticket.id}</span>
                      <span className="text-[10px] text-slate-500 font-sans">
                        Logged on {new Date(ticket.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    {ticket.status === "converted" ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-800 border border-emerald-200">
                        <UserCheck className="h-3.5 w-3.5" /> Account Generated
                      </span>
                    ) : ticket.status === "archived" ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-500 border border-slate-200">
                        Archived
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-orange-100 px-2.5 py-1 text-xs font-semibold text-orange-900 border border-orange-200 animate-pulse">
                        ● Pending Review
                      </span>
                    )}
                  </div>

                  {/* Core details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-900">{ticket.customerName}</h4>
                      <p className="text-xs text-slate-500 font-sans flex items-center gap-1.5">
                        <Phone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                        <span>{ticket.phone || "No phone"}</span>
                      </p>
                      <p className="text-xs text-slate-500 font-sans flex items-center gap-1.5">
                        <Mail className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{ticket.email || "No email"}</span>
                      </p>
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">Property Site</div>
                      <p className="text-xs text-slate-700 font-sans flex items-start gap-1.5 leading-tight">
                        <MapPin className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{ticket.address}</span>
                      </p>
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs font-medium text-slate-400 uppercase tracking-wider animate-pulse">Schedule Option</div>
                      <p className="text-xs text-slate-700 font-sans flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                        <span>Prefers: <span className="font-semibold text-slate-900">{ticket.preferredDate}</span></span>
                      </p>
                      <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-500 px-2 py-0.5 rounded">
                        via {ticket.source}
                      </span>
                    </div>
                  </div>

                  {/* Notes / Issue description */}
                  <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 hover:bg-slate-50 transition">
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 leading-none">
                      Problem notes & descriptions
                    </span>
                    <p className="text-xs text-slate-600 font-sans leading-relaxed">
                      {ticket.notes}
                    </p>
                  </div>

                  {/* Convert Call to Action */}
                  {ticket.status === "pending" && (
                    <div className="flex items-center justify-end pt-2 shrink-0">
                      <button
                        id={`convert-btn-${ticket.id}`}
                        onClick={() => onConvertIntake(ticket.id)}
                        className="py-1.5 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-900 text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                      >
                        <UserCheck className="h-4 w-4" />
                        <span>Generate & Set Up Home Memory Asset</span>
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
